# A2_231A010025 — Flutter stopwatch lab

Flutter implementation of Lab A2: app lifecycle, stopwatch state restoration,
periodic UI updates, Git workflow, and two optional enhancements (Lap and
"Stop when in background").

## Run

```powershell
cd G:\A2_231A010025
flutter pub get
flutter run
```

Requires Flutter and an Android device or emulator. Android `minSdk` is 24.
The stopwatch reads Android `SystemClock.elapsedRealtime()` through a
`MethodChannel`, so elapsed time is monotonic and remains correct across
backgrounding, rotation, and Android state restoration.

## Personalize before submission

The full name in `lib/main.dart` is set to Nguyễn Thịnh Phú. The student ID
and app/log tag are already set to `231A010025` / `A2_231A010025`.

## Lab feature map

- Start, pause, reset, hundredths-of-a-second display, and running/paused status.
- A 100 ms `Timer.periodic` updates only while the app is foregrounded and the
  stopwatch is running; it is cancelled on pause/dispose to avoid duplicate
  timers and retained callbacks.
- `RestorationMixin` stores the running flag, accumulated time, monotonic start
  value, recreation counter, background option, and lap list.
- `WidgetsBindingObserver` handles Flutter app lifecycle changes. The optional
  switch pauses the stopwatch when the app leaves the foreground.
- Rotation adapts the layout and increments the displayed recreation counter;
  Flutter logs the Activity lifecycle under tag `A2_231A010025`.
- Lap records survive state restoration. The display turns red after 60
  seconds.

Flutter manages lifecycle through `WidgetsBindingObserver`, rather than
exposing Android Activity callbacks directly to Dart. Native Activity callbacks
are logged in `MainActivity.kt`; stopwatch state is restored by Flutter's
restoration system.

## Validation and submission

Run `flutter analyze`, `flutter test`, and `flutter build apk --debug`. See
[`REPORT_TEMPLATE.md`](./REPORT_TEMPLATE.md) for the five scenario checklist,
analysis answers, evidence placeholders, and GitHub submission steps. Complete
real-device observations, screenshots, private GitHub repository, instructor
invitation, and the ≤2-minute demo video yourself; these require your device,
account, name, and instructor's GitHub username.
