import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const _studentId = '231A010025';
const _studentName = 'Nguyễn Thịnh Phú';
const _clockChannel = MethodChannel('vn.edu.vhu.ltdd.a2_231a010025/clock');

void main() {
  runApp(const StopwatchApp());
}

class StopwatchApp extends StatelessWidget {
  const StopwatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'A2_$_studentId',
      debugShowCheckedModeBanner: false,
      restorationScopeId: 'a2-stopwatch',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF155EEF),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        useMaterial3: true,
      ),
      home: const StopwatchPage(),
    );
  }
}

class StopwatchPage extends StatefulWidget {
  const StopwatchPage({super.key});

  @override
  State<StopwatchPage> createState() => _StopwatchPageState();
}

class _StopwatchPageState extends State<StopwatchPage>
    with RestorationMixin, WidgetsBindingObserver {
  final RestorableBool _running = RestorableBool(false);
  final RestorableInt _accumulatedMs = RestorableInt(0);
  final RestorableInt _startElapsedMs = RestorableInt(0);
  final RestorableInt _recreateCount = RestorableInt(0);
  final RestorableBool _stopOnBackground = RestorableBool(false);
  final RestorableBool _hasRestoredBefore = RestorableBool(false);
  final RestorableString _lapsJson = RestorableString('[]');
  Timer? _ticker;
  bool _isResumed = true;
  bool _busy = false;
  Orientation? _lastOrientation;
  int _currentElapsedMs = 0;

  @override
  String? get restorationId => 'stopwatch-page';

  List<String> get _laps =>
      (jsonDecode(_lapsJson.value) as List<dynamic>).cast<String>();

  @override
  void restoreState(RestorationBucket? oldBucket, bool initialRestore) {
    registerForRestoration(_running, 'running');
    registerForRestoration(_accumulatedMs, 'accumulated-ms');
    registerForRestoration(_startElapsedMs, 'start-elapsed-ms');
    registerForRestoration(_recreateCount, 'recreate-count');
    registerForRestoration(_stopOnBackground, 'stop-on-background');
    registerForRestoration(_hasRestoredBefore, 'has-restored-before');
    registerForRestoration(_lapsJson, 'laps');
    if (_hasRestoredBefore.value) {
      _recreateCount.value++;
    }
    _hasRestoredBefore.value = true;
    _syncTicker();
    if (_running.value) {
      unawaited(_refreshDisplayedTime());
    }
    debugPrint(
      'A2_$_studentId: state restored (running=${_running.value}, '
      'elapsed=${_elapsedMs}ms)',
    );
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    debugPrint('A2_$_studentId: onCreate');
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final orientation = MediaQuery.orientationOf(context);
    if (_lastOrientation != null && _lastOrientation != orientation) {
      _recreateCount.value++;
      debugPrint(
        'A2_$_studentId: orientation changed; stopwatch state retained',
      );
    }
    _lastOrientation = orientation;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    debugPrint('A2_$_studentId: lifecycle=$state');
    _isResumed = state == AppLifecycleState.resumed;
    if (!_isResumed && _stopOnBackground.value && _running.value) {
      unawaited(_pauseStopwatch());
    }
    _syncTicker();
    if (mounted) {
      setState(() {});
    }
  }

  Future<int> _readElapsedRealtime() async {
    try {
      return await _clockChannel.invokeMethod<int>('elapsedRealtime') ??
          (throw StateError('Android returned no elapsedRealtime value.'));
    } on PlatformException catch (error) {
      debugPrint('A2_$_studentId: unable to read monotonic clock: $error');
      rethrow;
    } on MissingPluginException {
      throw StateError('The Android monotonic clock channel is unavailable.');
    }
  }

  int get _elapsedMs {
    if (!_running.value) return _accumulatedMs.value;
    if (_currentElapsedMs < _startElapsedMs.value) {
      return _accumulatedMs.value;
    }
    return _accumulatedMs.value + _currentElapsedMs - _startElapsedMs.value;
  }

  Future<void> _startStopwatch() async {
    if (_busy || _running.value) return;
    setState(() => _busy = true);
    try {
      final now = await _readElapsedRealtime();
      if (!mounted) return;
      _currentElapsedMs = now;
      _startElapsedMs.value = now;
      _running.value = true;
      _syncTicker();
      debugPrint('A2_$_studentId: START');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pauseStopwatch() async {
    if (!_running.value) return;
    final now = await _readElapsedRealtime();
    if (!mounted || !_running.value) return;
    _currentElapsedMs = now;
    _accumulatedMs.value += now - _startElapsedMs.value;
    _running.value = false;
    _syncTicker();
    setState(() {});
    debugPrint('A2_$_studentId: PAUSE at ${_accumulatedMs.value}ms');
  }

  void _resetStopwatch() {
    _running.value = false;
    _accumulatedMs.value = 0;
    _startElapsedMs.value = 0;
    _lapsJson.value = '[]';
    _syncTicker();
    debugPrint('A2_$_studentId: RESET');
    setState(() {});
  }

  Future<void> _addLap() async {
    if (!_running.value) return;
    final now = await _readElapsedRealtime();
    if (!mounted || !_running.value) return;
    final laps = _laps;
    laps.insert(
      0,
      _formatTime(_accumulatedMs.value + now - _startElapsedMs.value),
    );
    _lapsJson.value = jsonEncode(laps);
    setState(() {});
  }

  void _syncTicker() {
    _ticker?.cancel();
    _ticker = null;
    if (_running.value && _isResumed) {
      _ticker = Timer.periodic(const Duration(milliseconds: 100), (_) {
        unawaited(_refreshDisplayedTime());
      });
    }
  }

  Future<void> _refreshDisplayedTime() async {
    final now = await _readElapsedRealtime();
    if (mounted && _running.value) {
      setState(() => _currentElapsedMs = now);
    }
  }

  String _formatTime(int milliseconds) {
    final minutes = milliseconds ~/ 60000;
    final seconds = (milliseconds % 60000) ~/ 1000;
    final centiseconds = ((milliseconds % 1000) ~/ 10).toString().padLeft(
      2,
      '0',
    );
    return '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}.$centiseconds';
  }

  @override
  void dispose() {
    _ticker?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _running.dispose();
    _accumulatedMs.dispose();
    _startElapsedMs.dispose();
    _recreateCount.dispose();
    _stopOnBackground.dispose();
    _hasRestoredBefore.dispose();
    _lapsJson.dispose();
    debugPrint('A2_$_studentId: onDestroy; ticker removed');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final elapsed = _elapsedMs;
    final running = _running.value;
    final timeColor = elapsed >= 60000
        ? const Color(0xFFB42318)
        : const Color(0xFF101828);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab A2 · Đồng hồ bấm giờ'),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.surface,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxHeight < 570;
            final content = Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '$_studentName · MSSV $_studentId',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium
                      ?.copyWith(color: const Color(0xFF475467)),
                ),
                SizedBox(height: compact ? 12 : 30),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    _formatTime(elapsed),
                    key: const ValueKey('stopwatch-time'),
                    style: TextStyle(
                      color: timeColor,
                      fontFamily: 'monospace',
                      fontSize: compact ? 56 : 72,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                _StatusBadge(running: running),
                SizedBox(height: compact ? 16 : 28),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  alignment: WrapAlignment.center,
                  children: [
                    FilledButton.icon(
                      onPressed: _busy
                          ? null
                          : running
                          ? () => unawaited(_pauseStopwatch())
                          : () => unawaited(_startStopwatch()),
                      icon: Icon(running ? Icons.pause : Icons.play_arrow),
                      label: Text(running ? 'Tạm dừng' : 'Bắt đầu'),
                    ),
                    OutlinedButton.icon(
                      onPressed: _resetStopwatch,
                      icon: const Icon(Icons.restart_alt),
                      label: const Text('Đặt lại'),
                    ),
                    OutlinedButton.icon(
                      onPressed: running ? () => unawaited(_addLap()) : null,
                      icon: const Icon(Icons.flag_outlined),
                      label: const Text('Vòng'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Dừng khi ra nền'),
                  subtitle: const Text('Tự tạm dừng khi rời ứng dụng'),
                  value: _stopOnBackground.value,
                  onChanged: (value) {
                    setState(() => _stopOnBackground.value = value);
                  },
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Số lần Activity được tạo lại: ${_recreateCount.value}',
                    key: const ValueKey('recreate-count'),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                if (_laps.isNotEmpty) ...[
                  const Divider(height: 24),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Vòng đã ghi',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ),
                  const SizedBox(height: 4),
                  for (var index = 0; index < _laps.length; index++)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        radius: 14,
                        child: Text('${_laps.length - index}'),
                      ),
                      title: Text(
                        _laps[index],
                        style: const TextStyle(fontFamily: 'monospace'),
                      ),
                    ),
                ],
              ],
            );
            return SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 560),
                  child: Card(
                    elevation: 0,
                    color: Theme.of(context).colorScheme.surface,
                    child: Padding(
                      padding: EdgeInsets.all(compact ? 18 : 28),
                      child: content,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.running});

  final bool running;

  @override
  Widget build(BuildContext context) {
    final color = running ? const Color(0xFF067647) : const Color(0xFF667085);
    return DecoratedBox(
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        child: Text(
          running ? 'Trạng thái: đang chạy' : 'Trạng thái: tạm dừng',
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
