import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:a2_231a010025/main.dart';

void main() {
  const clock = MethodChannel('vn.edu.vhu.ltdd.a2_231a010025/clock');
  var elapsedRealtime = 100000;

  setUp(() {
    elapsedRealtime = 100000;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(clock, (call) async {
          expect(call.method, 'elapsedRealtime');
          return elapsedRealtime;
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(clock, null);
  });

  testWidgets('starts, pauses, and resets the stopwatch', (tester) async {
    await tester.pumpWidget(const StopwatchApp());
    expect(find.text('00:00.00'), findsOneWidget);
    expect(find.text('Trạng thái: tạm dừng'), findsOneWidget);

    await tester.tap(find.text('Bắt đầu'));
    await tester.pump();
    elapsedRealtime += 2300;
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump();
    expect(find.text('00:02.30'), findsOneWidget);
    expect(find.text('Trạng thái: đang chạy'), findsOneWidget);

    await tester.tap(find.text('Tạm dừng'));
    await tester.pump();
    await tester.pump();
    elapsedRealtime += 5000;
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('00:02.30'), findsOneWidget);

    await tester.tap(find.text('Đặt lại'));
    await tester.pump();
    expect(find.text('00:00.00'), findsOneWidget);
    expect(find.text('Bắt đầu'), findsOneWidget);
  });

  testWidgets('records laps while running and clears them on reset', (
    tester,
  ) async {
    await tester.pumpWidget(const StopwatchApp());
    await tester.tap(find.text('Bắt đầu'));
    await tester.pump();
    elapsedRealtime += 4500;

    await tester.tap(find.text('Vòng'));
    await tester.pump();
    await tester.pump();
    expect(find.text('Vòng đã ghi'), findsOneWidget);
    expect(find.text('00:04.50'), findsWidgets);

    await tester.tap(find.text('Đặt lại'));
    await tester.pump();
    expect(find.text('Vòng đã ghi'), findsNothing);
  });

  testWidgets('restores the running stopwatch and laps after app recreation', (
    tester,
  ) async {
    await tester.pumpWidget(const StopwatchApp());
    await tester.tap(find.text('Bắt đầu'));
    await tester.pump();
    elapsedRealtime += 2500;
    await tester.tap(find.text('Vòng'));
    await tester.pump();
    await tester.pump();

    await tester.restartAndRestore();
    await tester.pump();

    expect(find.text('Trạng thái: đang chạy'), findsOneWidget);
    expect(find.text('00:02.50'), findsWidgets);
    expect(find.text('Số lần Activity được tạo lại: 1'), findsOneWidget);
  });

  testWidgets('stops when moved to the background when the option is enabled', (
    tester,
  ) async {
    await tester.pumpWidget(const StopwatchApp());
    await tester.tap(find.text('Dừng khi ra nền'));
    await tester.pump();
    await tester.tap(find.text('Bắt đầu'));
    await tester.pump();

    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
    await tester.pump();
    await tester.pump();
    expect(find.text('Trạng thái: tạm dừng'), findsOneWidget);
  });
}
