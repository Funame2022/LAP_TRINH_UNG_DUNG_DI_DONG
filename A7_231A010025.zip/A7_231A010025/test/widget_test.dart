import 'package:a7permission/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

const MethodChannel permissionChannel = MethodChannel(
  'vn.edu.vhu.ltdd.a7permission/permissions',
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, null);
  });

  testWidgets('Shows A7 controls and the current permission status', (
    WidgetTester tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, (MethodCall call) async {
          if (call.method == 'getPermissionStatus') {
            return <String, Object>{
              'cameraGranted': false,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          return null;
        });

    await tester.pumpWidget(const A7PermissionApp());
    await tester.pumpAndSettle();

    expect(find.text('Lab A7 · Quyền truy cập'), findsOneWidget);
    expect(find.text('Nguyễn Thịnh Phú · MSSV 231A010025'), findsOneWidget);
    expect(find.text('CAMERA: CHƯA CẤP'), findsOneWidget);
    expect(find.text('THÔNG BÁO: CHƯA CẤP'), findsOneWidget);
    expect(find.text('Android API 37'), findsOneWidget);
    expect(find.byKey(const Key('takePicture')), findsOneWidget);
    expect(find.byKey(const Key('sendNotification')), findsOneWidget);
    expect(find.byKey(const Key('openSettings')), findsOneWidget);
  });

  testWidgets('Reports a camera permission denial', (
    WidgetTester tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, (MethodCall call) async {
          if (call.method == 'getPermissionStatus') {
            return <String, Object>{
              'cameraGranted': false,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          if (call.method == 'takePicture') {
            return <String, Object>{
              'status': 'denied',
              'cameraGranted': false,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          return null;
        });

    await tester.pumpWidget(const A7PermissionApp());
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('takePicture')));
    await tester.tap(find.byKey(const Key('takePicture')));
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('lastMessage')), findsOneWidget);
  });

  testWidgets('Explains permanent denial and offers application settings', (
    WidgetTester tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, (MethodCall call) async {
          if (call.method == 'getPermissionStatus') {
            return <String, Object>{
              'cameraGranted': false,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          if (call.method == 'takePicture') {
            return <String, Object>{
              'status': 'blocked',
              'cameraGranted': false,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          return null;
        });

    await tester.pumpWidget(const A7PermissionApp());
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('takePicture')));
    await tester.tap(find.byKey(const Key('takePicture')));
    await tester.pumpAndSettle();

    expect(find.text('Quyền CAMERA đang bị chặn'), findsOneWidget);
    expect(find.text('Mở Cài đặt'), findsOneWidget);
  });

  testWidgets('Updates camera status after a successful permission result', (
    WidgetTester tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, (MethodCall call) async {
          if (call.method == 'getPermissionStatus') {
            return <String, Object>{
              'cameraGranted': true,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          if (call.method == 'takePicture') {
            return <String, Object>{
              'status': 'granted',
              'cameraGranted': true,
              'notificationsGranted': false,
              'androidApi': 37,
            };
          }
          return null;
        });

    await tester.pumpWidget(const A7PermissionApp());
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('takePicture')));
    await tester.tap(find.byKey(const Key('takePicture')));
    await tester.pumpAndSettle();

    expect(find.text('CAMERA: ĐÃ CẤP'), findsOneWidget);
  });
}
