import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const A7PermissionApp());
}

class A7PermissionApp extends StatelessWidget {
  const A7PermissionApp({super.key});

  @override
  Widget build(BuildContext context) {
    const Color seed = Color(0xFF3157A4);
    return MaterialApp(
      title: 'Lab A7 · Runtime Permission',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
        cardTheme: const CardThemeData(margin: EdgeInsets.zero, elevation: 1),
      ),
      home: const PermissionHomePage(),
    );
  }
}

class PermissionHomePage extends StatefulWidget {
  const PermissionHomePage({super.key});

  @override
  State<PermissionHomePage> createState() => _PermissionHomePageState();
}

class _PermissionHomePageState extends State<PermissionHomePage>
    with WidgetsBindingObserver {
  static const MethodChannel _channel = MethodChannel(
    'vn.edu.vhu.ltdd.a7permission/permissions',
  );

  bool _cameraGranted = false;
  bool _notificationsGranted = false;
  int _androidApi = 0;
  bool _busy = false;
  Uint8List? _previewBytes;
  int? _previewWidth;
  int? _previewHeight;
  String? _lastMessage;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _channel.setMethodCallHandler(_handleNativeCall);
    _refreshPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _channel.setMethodCallHandler(null);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshPermissions();
    }
  }

  Future<void> _handleNativeCall(MethodCall call) async {
    if (call.method == 'permissionsUpdated') {
      _applyPermissionSnapshot(_asMap(call.arguments));
    }
  }

  Map<String, Object?> _asMap(Object? value) {
    if (value is Map) {
      return value.map<String, Object?>(
        (Object? key, Object? value) => MapEntry(key.toString(), value),
      );
    }
    return const <String, Object?>{};
  }

  void _applyPermissionSnapshot(Map<String, Object?> snapshot) {
    if (!mounted) {
      return;
    }
    final bool cameraGranted = snapshot['cameraGranted'] == true;
    final bool notificationsGranted = snapshot['notificationsGranted'] == true;
    final bool permissionsChanged =
        cameraGranted != _cameraGranted ||
        notificationsGranted != _notificationsGranted;
    setState(() {
      _cameraGranted = cameraGranted;
      _notificationsGranted = notificationsGranted;
      _androidApi = snapshot['androidApi'] is int
          ? snapshot['androidApi']! as int
          : 0;
      if (permissionsChanged) {
        _lastMessage = null;
      }
    });
  }

  Future<Map<String, Object?>> _invoke(String method) async {
    final Object? result = await _channel.invokeMethod<Object?>(method);
    return _asMap(result);
  }

  Future<void> _refreshPermissions() async {
    try {
      final Map<String, Object?> status = await _invoke('getPermissionStatus');
      _applyPermissionSnapshot(status);
    } on PlatformException catch (error) {
      _showMessage(
        'Không đọc được trạng thái quyền: ${error.message ?? error.code}',
      );
    } on MissingPluginException {
      _showMessage('Không kết nối được dịch vụ quyền Android.');
    }
  }

  Future<void> _takePicture() async {
    if (_busy) {
      return;
    }
    setState(() => _busy = true);
    try {
      final Map<String, Object?> result = await _invoke('takePicture');
      await _handleCameraResult(result);
    } on PlatformException catch (error) {
      _showMessage('Không thể mở camera: ${error.message ?? error.code}');
    } on MissingPluginException {
      _showMessage('Chức năng camera chỉ khả dụng trên Android.');
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _handleCameraResult(Map<String, Object?> result) async {
    switch (result['status']) {
      case 'rationale':
        final bool? continueRequest = await showDialog<bool>(
          context: context,
          builder: (BuildContext context) => AlertDialog(
            icon: const Icon(Icons.info_outline),
            title: const Text('Vì sao cần quyền CAMERA?'),
            content: const Text(
              'Ứng dụng cần quyền CAMERA để chụp và hiển thị ảnh xem trước. '
              'Nếu bạn không cấp quyền, nút Chụp ảnh sẽ không hoạt động.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Để sau'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Đồng ý'),
              ),
            ],
          ),
        );
        if (continueRequest == true) {
          final Map<String, Object?> requested = await _invoke(
            'requestCameraPermission',
          );
          await _handleCameraResult(requested);
        }
      case 'blocked':
        final bool? openSettings = await showDialog<bool>(
          context: context,
          builder: (BuildContext context) => AlertDialog(
            icon: const Icon(Icons.block_outlined),
            title: const Text('Quyền CAMERA đang bị chặn'),
            content: const Text(
              'Android sẽ không hiện lại hộp thoại quyền. '
              'Bạn có thể mở Cài đặt ứng dụng để bật quyền CAMERA thủ công.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Đóng'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Mở Cài đặt'),
              ),
            ],
          ),
        );
        if (openSettings == true) {
          await _openSettings();
        }
      case 'denied':
        _showMessage('Bạn chưa cấp quyền CAMERA. Nhấn Chụp ảnh để thử lại.');
      case 'granted':
        final Object? image = result['image'];
        if (image is Uint8List) {
          setState(() {
            _cameraGranted = true;
            _previewBytes = image;
            _previewWidth = result['width'] is int
                ? result['width']! as int
                : null;
            _previewHeight = result['height'] is int
                ? result['height']! as int
                : null;
            _lastMessage = 'Đã chụp ảnh xem trước từ camera.';
          });
        } else {
          _applyPermissionSnapshot(result);
          if (result['message'] is String) {
            _showMessage(result['message']! as String);
          }
        }
      default:
        _showMessage('Camera chưa trả về kết quả. Vui lòng thử lại.');
    }
  }

  Future<void> _sendNotification() async {
    if (_busy) {
      return;
    }
    setState(() => _busy = true);
    try {
      final Map<String, Object?> result = await _invoke('sendNotification');
      switch (result['status']) {
        case 'sent':
          _notificationsGranted = true;
          _showMessage(
            result['message'] as String? ?? 'Đã gửi thông báo Lab A7.',
          );
        case 'denied':
          _notificationsGranted = false;
          _showMessage('Bạn đã từ chối quyền gửi thông báo.');
        case 'granted':
          _notificationsGranted = true;
          _showMessage('Đã cấp quyền thông báo.');
        default:
          _showMessage('Không gửi được thông báo. Vui lòng thử lại.');
      }
      if (mounted) {
        setState(() {});
      }
    } on PlatformException catch (error) {
      _showMessage('Không thể gửi thông báo: ${error.message ?? error.code}');
    } on MissingPluginException {
      _showMessage('Chức năng thông báo chỉ khả dụng trên Android.');
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _openSettings() async {
    try {
      await _invoke('openAppSettings');
    } on PlatformException catch (error) {
      _showMessage('Không mở được Cài đặt: ${error.message ?? error.code}');
    }
  }

  void _showMessage(String message) {
    if (!mounted) {
      return;
    }
    setState(() => _lastMessage = message);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab A7 · Quyền truy cập'),
        actions: <Widget>[
          IconButton(
            key: const Key('refreshPermissions'),
            tooltip: 'Cập nhật trạng thái quyền',
            onPressed: _refreshPermissions,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            final Widget content = _buildContent(theme);
            if (constraints.maxWidth < 760) {
              return SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: content,
              );
            }
            return Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1120),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: content,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildContent(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Card(
          color: theme.colorScheme.primaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: <Widget>[
                Icon(
                  Icons.verified_user_outlined,
                  size: 42,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Xin quyền có trách nhiệm',
                        style: theme.textTheme.titleLarge?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Nguyễn Thịnh Phú · MSSV 231A010025',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Trạng thái quyền', style: theme.textTheme.titleMedium),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    _PermissionChip(label: 'CAMERA', granted: _cameraGranted),
                    _PermissionChip(
                      label: 'THÔNG BÁO',
                      granted: _notificationsGranted,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  _androidApi == 0
                      ? 'Đang đọc phiên bản Android…'
                      : 'Android API $_androidApi',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            height: 240,
            child: _previewBytes == null
                ? ColoredBox(
                    color: theme.colorScheme.surfaceContainerHighest,
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Icon(Icons.photo_camera_outlined, size: 54),
                          SizedBox(height: 8),
                          Text('Ảnh xem trước sẽ xuất hiện tại đây'),
                        ],
                      ),
                    ),
                  )
                : Image.memory(_previewBytes!, fit: BoxFit.contain),
          ),
        ),
        if (_previewWidth != null && _previewHeight != null) ...<Widget>[
          const SizedBox(height: 8),
          Text(
            'Ảnh xem trước: $_previewWidth × $_previewHeight pixel',
            textAlign: TextAlign.center,
          ),
        ],
        const SizedBox(height: 16),
        FilledButton.icon(
          key: const Key('takePicture'),
          onPressed: _busy ? null : _takePicture,
          icon: const Icon(Icons.camera_alt_outlined),
          label: const Text('Chụp ảnh'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          key: const Key('sendNotification'),
          onPressed: _busy ? null : _sendNotification,
          icon: const Icon(Icons.notifications_active_outlined),
          label: const Text('Gửi thông báo'),
        ),
        const SizedBox(height: 8),
        TextButton.icon(
          key: const Key('openSettings'),
          onPressed: _openSettings,
          icon: const Icon(Icons.settings_outlined),
          label: const Text('Mở Cài đặt ứng dụng'),
        ),
        if (_lastMessage != null) ...<Widget>[
          const SizedBox(height: 8),
          Text(
            _lastMessage!,
            key: const Key('lastMessage'),
            textAlign: TextAlign.center,
            style: theme.textTheme.bodySmall,
          ),
        ],
      ],
    );
  }
}

class _PermissionChip extends StatelessWidget {
  const _PermissionChip({required this.label, required this.granted});

  final String label;
  final bool granted;

  @override
  Widget build(BuildContext context) {
    final Color color = granted
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).colorScheme.error;
    return Chip(
      avatar: Icon(
        granted ? Icons.check_circle : Icons.block,
        size: 18,
        color: color,
      ),
      label: Text('$label: ${granted ? 'ĐÃ CẤP' : 'CHƯA CẤP'}'),
      side: BorderSide(color: color.withValues(alpha: 0.35)),
    );
  }
}
