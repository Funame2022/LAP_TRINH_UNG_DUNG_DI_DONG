package vn.edu.vhu.ltdd.a7permission

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterFragmentActivity() {
    companion object {
        private const val CHANNEL = "vn.edu.vhu.ltdd.a7permission/permissions"
        private const val NOTIFICATION_CHANNEL_ID = "a7_permission_updates"
        private const val NOTIFICATION_ID = 7001
        private const val TAG = "A7Permission"
        private const val PREFS = "a7_permission_state"
        private const val CAMERA_REQUESTED = "camera_requested"
    }

    private var methodChannel: MethodChannel? = null
    private var pendingCameraResult: MethodChannel.Result? = null
    private var pendingNotificationResult: MethodChannel.Result? = null

    private val cameraPermissionLauncher: ActivityResultLauncher<String> =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Log.d(TAG, "CAMERA permission result: $granted")
            val pending = pendingCameraResult ?: return@registerForActivityResult
            if (granted) {
                launchPicturePreview(pending, fromPermissionResult = true)
            } else {
                val state = if (
                    shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
                ) {
                    "denied"
                } else {
                    "blocked"
                }
                pendingCameraResult = null
                pending.success(permissionSnapshot() + ("status" to state))
            }
        }

    private val picturePreviewLauncher: ActivityResultLauncher<Void?> =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
            val pending = pendingCameraResult ?: return@registerForActivityResult
            pendingCameraResult = null
            if (bitmap == null) {
                pending.success(
                    permissionSnapshot() +
                        mapOf("status" to "granted", "message" to "photo_cancelled"),
                )
            } else {
                pending.success(photoResult(bitmap))
            }
        }

    private val notificationPermissionLauncher: ActivityResultLauncher<String> =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Log.d(TAG, "POST_NOTIFICATIONS permission result: $granted")
            val pending = pendingNotificationResult ?: return@registerForActivityResult
            pendingNotificationResult = null
            if (granted) {
                postLabNotification(pending)
            } else {
                pending.success(permissionSnapshot() + ("status" to "denied"))
            }
        }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        methodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL,
        ).also { channel ->
            channel.setMethodCallHandler(::handleMethodCall)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
    }

    override fun onResume() {
        super.onResume()
        Handler(Looper.getMainLooper()).post {
            methodChannel?.invokeMethod("permissionsUpdated", permissionSnapshot())
        }
    }

    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "getPermissionStatus" -> result.success(permissionSnapshot())
            "takePicture" -> takePicture(result)
            "requestCameraPermission" -> requestCameraPermission(result)
            "sendNotification" -> sendNotification(result)
            "openAppSettings" -> openAppSettings(result)
            else -> result.notImplemented()
        }
    }

    private fun takePicture(result: MethodChannel.Result) {
        if (hasCameraPermission()) {
            launchPicturePreview(result)
            return
        }

        val wasRequested = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getBoolean(CAMERA_REQUESTED, false)
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            result.success(permissionSnapshot() + ("status" to "rationale"))
        } else if (wasRequested) {
            result.success(permissionSnapshot() + ("status" to "blocked"))
        } else {
            launchCameraPermission(result)
        }
    }

    private fun requestCameraPermission(result: MethodChannel.Result) {
        if (hasCameraPermission()) {
            launchPicturePreview(result)
        } else if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            launchCameraPermission(result)
        } else {
            val wasRequested = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(CAMERA_REQUESTED, false)
            result.success(
                permissionSnapshot() +
                    ("status" to if (wasRequested) "blocked" else "denied"),
            )
        }
    }

    private fun launchCameraPermission(result: MethodChannel.Result) {
        if (pendingCameraResult != null) {
            result.error("REQUEST_IN_PROGRESS", "Đang chờ kết quả quyền CAMERA.", null)
            return
        }
        pendingCameraResult = result
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(CAMERA_REQUESTED, true)
            .apply()
        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun launchPicturePreview(
        result: MethodChannel.Result,
        fromPermissionResult: Boolean = false,
    ) {
        if (pendingCameraResult != null && !fromPermissionResult) {
            result.error("REQUEST_IN_PROGRESS", "Đang chờ kết quả camera.", null)
            return
        }
        pendingCameraResult = result
        picturePreviewLauncher.launch(null)
    }

    private fun photoResult(bitmap: Bitmap): Map<String, Any> {
        val output = ByteArrayOutputStream()
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
            "Không thể mã hóa ảnh xem trước."
        }
        return permissionSnapshot() + mapOf(
            "status" to "granted",
            "image" to output.toByteArray(),
            "width" to bitmap.width,
            "height" to bitmap.height,
        )
    }

    private fun sendNotification(result: MethodChannel.Result) {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (pendingNotificationResult != null) {
                result.error(
                    "REQUEST_IN_PROGRESS",
                    "Đang chờ kết quả quyền thông báo.",
                    null,
                )
                return
            }
            pendingNotificationResult = result
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            postLabNotification(result)
        }
    }

    private fun postLabNotification(result: MethodChannel.Result) {
        val manager = getSystemService(NotificationManager::class.java)
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(this, NOTIFICATION_CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(this)
        }
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Xin chào từ Lab A7")
            .setContentText("Bạn vừa gửi thông báo thành công.")
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
            result.success(
                permissionSnapshot() +
                    mapOf("status" to "sent", "message" to "Đã gửi thông báo Lab A7."),
            )
        } catch (error: SecurityException) {
            result.error(
                "NOTIFICATION_PERMISSION",
                error.message ?: "Quyền thông báo chưa được cấp.",
                null,
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Thông báo Lab A7",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Kênh minh họa cho bài thực hành A7."
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun openAppSettings(result: MethodChannel.Result) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        )
        if (intent.resolveActivity(packageManager) == null) {
            result.error("SETTINGS_UNAVAILABLE", "Không tìm thấy Cài đặt ứng dụng.", null)
            return
        }
        startActivity(intent)
        result.success(null)
    }

    private fun permissionSnapshot(): Map<String, Any> {
        val notificationsGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        return mapOf(
            "cameraGranted" to hasCameraPermission(),
            "notificationsGranted" to notificationsGranted,
            "androidApi" to Build.VERSION.SDK_INT,
        )
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA,
        ) == PackageManager.PERMISSION_GRANTED
}
