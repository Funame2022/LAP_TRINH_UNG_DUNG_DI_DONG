# A7_231A010025 — Runtime Permission (Flutter)

Ứng dụng thực hành quyền truy cập Android theo Lab A7. Giao diện được viết
bằng Flutter; `MainActivity.kt` gọi AndroidX Activity Result APIs qua
`MethodChannel` để hộp thoại quyền, xem trước camera và thông báo là hành vi
thật của Android.

## Chạy và kiểm tra

```powershell
flutter pub get
flutter test
flutter analyze
flutter run -d emulator-5554
```

Để xóa dữ liệu nội bộ và thu hồi quyền hiện đã cấp trên AVD:

```powershell
adb shell pm clear vn.edu.vhu.ltdd.a7permission
adb shell pm revoke vn.edu.vhu.ltdd.a7permission android.permission.CAMERA
adb shell pm revoke vn.edu.vhu.ltdd.a7permission android.permission.POST_NOTIFICATIONS
```

`pm clear` chỉ xóa dữ liệu/SharedPreferences của app, không tự đặt lại quyết định
xin quyền của Android. Muốn kiểm tra đúng trạng thái cài mới, gỡ rồi cài lại APK
trên AVD.

Bật camera trước/sau là **Emulated** trong cấu hình AVD. Camera preview dùng
`ActivityResultContracts.TakePicturePreview()` và không lưu ảnh vào bộ nhớ.

## Phạm vi quyền

- `CAMERA`: manifest + runtime request, hộp thoại giải thích khi bị từ chối,
  hướng dẫn mở App Settings khi Android đã chặn hộp thoại, cập nhật trạng thái
  khi Activity quay lại foreground.
- `POST_NOTIFICATIONS`: chỉ xin trên Android 13/API 33 trở lên; phiên bản cũ hơn
  gửi thông báo mà không xin runtime permission. Tạo NotificationChannel từ
  Android 8/API 26.
- Nâng cao NC3: notification có `PendingIntent` để mở lại ứng dụng.
- Nâng cao NC4: báo cáo có sơ đồ luồng CAMERA/notification.

Báo cáo Word: `docs/Lab_A7_BaoCao.docx`. Video quay màn hình AVD:
`docs/evidence/Lab_A7_Demo.mp4` (110,73 giây, dưới 2 phút). Ảnh minh chứng
được lưu trong `docs/evidence/`. Thông tin sinh viên hiện dùng là Nguyễn Thịnh
Phú, MSSV 231A010025; hãy xác nhận nếu thông tin nộp bài khác.
