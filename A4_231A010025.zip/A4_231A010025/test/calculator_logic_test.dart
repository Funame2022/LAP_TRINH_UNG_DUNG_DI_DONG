import 'package:a4events/calculator_logic.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('parseLocalizedNumber', () {
    test('accepts decimal points, decimal commas, and surrounding spaces', () {
      expect(parseLocalizedNumber(' 1.70 '), 1.7);
      expect(parseLocalizedNumber('1,70'), 1.7);
      expect(parseLocalizedNumber('-.5'), -0.5);
    });

    test('rejects malformed, empty, and ambiguous input', () {
      expect(parseLocalizedNumber(''), isNull);
      expect(parseLocalizedNumber('abc'), isNull);
      expect(parseLocalizedNumber('1.5.5'), isNull);
      expect(parseLocalizedNumber('1,000.5'), isNull);
      expect(parseLocalizedNumber('-'), isNull);
    });
  });

  group('BMI', () {
    test('converts centimeters and meters to the same value', () {
      expect(calculateBmi(60, 1.7), closeTo(20.7612, 0.001));
      expect(calculateBmi(60, 170), closeTo(20.7612, 0.001));
    });

    test('uses Asian BMI thresholds', () {
      expect(classifyBmi(18.49), BmiCategory.underweight);
      expect(classifyBmi(18.5), BmiCategory.normal);
      expect(classifyBmi(22.99), BmiCategory.normal);
      expect(classifyBmi(23), BmiCategory.overweight);
      expect(classifyBmi(24.99), BmiCategory.overweight);
      expect(classifyBmi(25), BmiCategory.obese);
    });
  });
}
