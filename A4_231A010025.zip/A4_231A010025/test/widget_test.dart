import 'package:a4events/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Shows calculator, BMI fields, and A4 identity', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();

    expect(find.text('Lab A4 · Máy tính & BMI'), findsOneWidget);
    expect(find.text('Nguyễn Thịnh Phú · MSSV 231A010025'), findsOneWidget);
    expect(find.text('Kết quả: —'), findsOneWidget);
    expect(find.text('BMI: —'), findsOneWidget);
    expect(find.byKey(const Key('operation+')), findsOneWidget);
    expect(find.byKey(const Key('operation−')), findsOneWidget);
    expect(find.byKey(const Key('operation×')), findsOneWidget);
    expect(find.byKey(const Key('operation÷')), findsOneWidget);
    expect(find.byKey(const Key('calculateBmi')), findsOneWidget);
  });

  testWidgets('Calculates and formats a division with a decimal result', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('numberA')), '12');
    await tester.enterText(find.byKey(const Key('numberB')), '3');
    await tester.tap(find.byKey(const Key('operation÷')));
    await tester.pumpAndSettle();

    expect(find.text('12,00 ÷ 3,00 = 4,00'), findsOneWidget);
  });

  testWidgets('Division by zero marks the second operand and does not crash', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('numberA')), '12');
    await tester.enterText(find.byKey(const Key('numberB')), '0');
    await tester.tap(find.byKey(const Key('operation÷')));
    await tester.pumpAndSettle();

    expect(find.text('Không thể chia cho 0.'), findsOneWidget);
    expect(find.text('Kết quả: —'), findsOneWidget);
  });

  testWidgets('Rejects pasted non-numeric text without crashing', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('numberA')), 'abc');
    await tester.enterText(find.byKey(const Key('numberB')), '2');
    await tester.tap(find.byKey(const Key('operation×')));
    await tester.pumpAndSettle();

    expect(find.text('Vui lòng nhập đúng định dạng số.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Rejects a parsed value outside the finite numeric range', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('numberA')), '1e9999');
    await tester.enterText(find.byKey(const Key('numberB')), '1');
    await tester.tap(find.byKey(const Key('operation+')));
    await tester.pumpAndSettle();

    expect(find.text('Giá trị phải là một số hữu hạn.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Moves focus to an empty calculator field', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('numberB')), '3');
    await tester.tap(find.byKey(const Key('operation+')));
    await tester.pumpAndSettle();

    expect(find.text('Vui lòng nhập số thứ nhất.'), findsOneWidget);
  });

  testWidgets('Calculates BMI from both meters and centimeters', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('weight')), '60');
    await tester.enterText(find.byKey(const Key('height')), '1.70');
    await tester.ensureVisible(find.byKey(const Key('calculateBmi')));
    await tester.tap(find.byKey(const Key('calculateBmi')));
    await tester.pumpAndSettle();
    expect(find.text('BMI: 20,8'), findsOneWidget);
    expect(find.text('Bình thường'), findsOneWidget);

    await tester.enterText(find.byKey(const Key('height')), '170');
    await tester.ensureVisible(find.byKey(const Key('calculateBmi')));
    await tester.tap(find.byKey(const Key('calculateBmi')));
    await tester.pumpAndSettle();
    expect(find.text('BMI: 20,8'), findsOneWidget);
    expect(find.text('Bình thường'), findsOneWidget);
  });

  testWidgets('Rejects zero BMI height at the height field', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('weight')), '60');
    await tester.enterText(find.byKey(const Key('height')), '0');
    await tester.ensureVisible(find.byKey(const Key('calculateBmi')));
    await tester.tap(find.byKey(const Key('calculateBmi')));
    await tester.pumpAndSettle();

    expect(find.text('Chiều cao phải lớn hơn 0.'), findsOneWidget);
    expect(find.text('BMI: —'), findsOneWidget);
  });

  testWidgets('Supports the sign and percent enhancements', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const A4EventsApp());
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('numberA')), '50');
    await tester.tap(find.byKey(const Key('percent')));
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<TextField>(find.byKey(const Key('numberA')))
          .controller!
          .text,
      '0,50',
    );
    await tester.tap(find.byKey(const Key('toggleSign')));
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<TextField>(find.byKey(const Key('numberA')))
          .controller!
          .text,
      '-0,50',
    );
  });
}
