import 'package:a4events/calculator_logic.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const A4EventsApp());
}

class A4EventsApp extends StatelessWidget {
  const A4EventsApp({super.key});

  @override
  Widget build(BuildContext context) {
    const Color seed = Color(0xFF3157A4);
    return MaterialApp(
      title: 'Lab A4 · Máy tính & BMI',
      debugShowCheckedModeBanner: false,
      locale: const Locale('vi', 'VN'),
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
        cardTheme: const CardThemeData(margin: EdgeInsets.zero, elevation: 1),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        ),
      ),
      home: const A4HomePage(),
    );
  }
}

class A4HomePage extends StatefulWidget {
  const A4HomePage({super.key});

  @override
  State<A4HomePage> createState() => _A4HomePageState();
}

class _A4HomePageState extends State<A4HomePage> {
  final TextEditingController _numberA = TextEditingController();
  final TextEditingController _numberB = TextEditingController();
  final TextEditingController _weight = TextEditingController();
  final TextEditingController _height = TextEditingController();
  final FocusNode _focusA = FocusNode();
  final FocusNode _focusB = FocusNode();
  final FocusNode _focusWeight = FocusNode();
  final FocusNode _focusHeight = FocusNode();
  final NumberFormat _numberFormat = NumberFormat('0.00', 'vi_VN');
  final NumberFormat _bmiFormat = NumberFormat('0.0', 'vi_VN');

  String _calculation = 'Kết quả: —';
  String _bmiValue = 'BMI: —';
  String _bmiCategory = 'Nhập cân nặng và chiều cao để bắt đầu.';
  Color _bmiColor = const Color(0xFF526176);
  String? _errorA;
  String? _errorB;
  String? _errorWeight;
  String? _errorHeight;

  @override
  void dispose() {
    _numberA.dispose();
    _numberB.dispose();
    _weight.dispose();
    _height.dispose();
    _focusA.dispose();
    _focusB.dispose();
    _focusWeight.dispose();
    _focusHeight.dispose();
    super.dispose();
  }

  double? _readNumber(
    TextEditingController controller,
    FocusNode focusNode,
    String fieldName,
  ) {
    final String input = controller.text.trim();
    if (input.isEmpty) {
      _setInputError(focusNode, 'Vui lòng nhập $fieldName.');
      return null;
    }
    final double? value = parseLocalizedNumber(input);
    if (value == null) {
      _showMessage('Vui lòng nhập đúng định dạng số.');
      return null;
    }
    if (!value.isFinite) {
      _setInputError(focusNode, 'Giá trị phải là một số hữu hạn.');
      return null;
    }
    return value;
  }

  void _setInputError(FocusNode focusNode, String message) {
    setState(() {
      if (focusNode == _focusA) {
        _errorA = message;
      } else if (focusNode == _focusB) {
        _errorB = message;
      } else if (focusNode == _focusWeight) {
        _errorWeight = message;
      } else {
        _errorHeight = message;
      }
    });
    focusNode.requestFocus();
  }

  void _clearInputErrors() {
    _errorA = null;
    _errorB = null;
    _errorWeight = null;
    _errorHeight = null;
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _calculate(String operation) {
    setState(_clearInputErrors);
    final double? a = _readNumber(_numberA, _focusA, 'số thứ nhất');
    if (a == null) {
      return;
    }
    final double? b = _readNumber(_numberB, _focusB, 'số thứ hai');
    if (b == null) {
      return;
    }
    if (operation == '÷' && b == 0) {
      _setInputError(_focusB, 'Không thể chia cho 0.');
      return;
    }

    final double result = switch (operation) {
      '+' => a + b,
      '−' => a - b,
      '×' => a * b,
      '÷' => a / b,
      _ => double.nan,
    };
    if (!result.isFinite) {
      _showMessage('Kết quả vượt ngoài miền số có thể biểu diễn.');
      return;
    }

    FocusScope.of(context).unfocus();
    setState(
      () => _calculation =
          '${_numberFormat.format(a)} $operation ${_numberFormat.format(b)} = '
          '${_numberFormat.format(result)}',
    );
  }

  void _toggleSign() {
    final double? value = _readNumber(_numberA, _focusA, 'số thứ nhất');
    if (value == null) {
      return;
    }
    setState(() {
      _numberA.text = _numberFormat.format(-value);
      _errorA = null;
    });
  }

  void _convertToPercent() {
    final double? value = _readNumber(_numberA, _focusA, 'số thứ nhất');
    if (value == null) {
      return;
    }
    setState(() {
      _numberA.text = _numberFormat.format(value / 100);
      _errorA = null;
    });
  }

  void _clearAll() {
    setState(() {
      _numberA.clear();
      _numberB.clear();
      _weight.clear();
      _height.clear();
      _clearInputErrors();
      _calculation = 'Kết quả: —';
      _bmiValue = 'BMI: —';
      _bmiCategory = 'Nhập cân nặng và chiều cao để bắt đầu.';
      _bmiColor = const Color(0xFF526176);
    });
    FocusScope.of(context).unfocus();
    _showMessage('Đã xóa dữ liệu.');
  }

  void _calculateBmi() {
    setState(_clearInputErrors);
    final double? weight = _readNumber(_weight, _focusWeight, 'cân nặng');
    if (weight == null) {
      return;
    }
    final double? height = _readNumber(_height, _focusHeight, 'chiều cao');
    if (height == null) {
      return;
    }
    if (weight <= 0) {
      _setInputError(_focusWeight, 'Cân nặng phải lớn hơn 0 kg.');
      return;
    }
    if (height <= 0) {
      _setInputError(_focusHeight, 'Chiều cao phải lớn hơn 0.');
      return;
    }

    final double bmi = calculateBmi(weight, height);
    if (!bmi.isFinite) {
      _showMessage('BMI vượt ngoài miền số có thể biểu diễn.');
      return;
    }
    final BmiCategory category = classifyBmi(bmi);
    final Color color = switch (category) {
      BmiCategory.underweight => const Color(0xFF3157A4),
      BmiCategory.normal => const Color(0xFF247A52),
      BmiCategory.overweight => const Color(0xFF9A6900),
      BmiCategory.obese => const Color(0xFFB3261E),
    };

    FocusScope.of(context).unfocus();
    setState(() {
      _bmiValue = 'BMI: ${_bmiFormat.format(bmi)}';
      _bmiCategory = category.label;
      _bmiColor = color;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab A4 · Máy tính & BMI'),
        centerTitle: false,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            final Widget content = _buildContent(theme);
            return SingleChildScrollView(
              padding: EdgeInsets.all(constraints.maxWidth < 600 ? 16 : 28),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 760),
                  child: content,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildContent(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Card(
          color: theme.colorScheme.primaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: <Widget>[
                Icon(
                  Icons.calculate_outlined,
                  size: 38,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Tính đúng · Kiểm tra đủ',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.onPrimaryContainer,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'Nguyễn Thịnh Phú · MSSV 231A010025',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        _sectionCard(
          theme,
          title: '1. Máy tính x/:/+/-',
          icon: Icons.functions,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: _numberField(
                      key: const Key('numberA'),
                      controller: _numberA,
                      focusNode: _focusA,
                      label: 'Số thứ nhất',
                      errorText: _errorA,
                      signed: true,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _numberField(
                      key: const Key('numberB'),
                      controller: _numberB,
                      focusNode: _focusB,
                      label: 'Số thứ hai',
                      errorText: _errorB,
                      signed: true,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.spaceBetween,
                children: <Widget>[
                  _operationButton('+', () => _calculate('+')),
                  _operationButton('−', () => _calculate('−')),
                  _operationButton('×', () => _calculate('×')),
                  _operationButton('÷', () => _calculate('÷')),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton.icon(
                      key: const Key('toggleSign'),
                      onPressed: _toggleSign,
                      icon: const Icon(Icons.exposure),
                      label: const Text('Đảo dấu ±'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      key: const Key('percent'),
                      onPressed: _convertToPercent,
                      icon: const Icon(Icons.percent),
                      label: const Text('Phần trăm %'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _resultPanel(
                key: const Key('calculationResult'),
                text: _calculation,
                color: theme.colorScheme.primary,
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                key: const Key('clearAll'),
                onPressed: _clearAll,
                icon: const Icon(Icons.clear_all),
                label: const Text('Xóa'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _sectionCard(
          theme,
          title: '2. Tính chỉ số BMI',
          icon: Icons.monitor_weight_outlined,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _numberField(
                key: const Key('weight'),
                controller: _weight,
                focusNode: _focusWeight,
                label: 'Cân nặng (kg)',
                errorText: _errorWeight,
              ),
              const SizedBox(height: 12),
              _numberField(
                key: const Key('height'),
                controller: _height,
                focusNode: _focusHeight,
                label: 'Chiều cao (m hoặc cm)',
                errorText: _errorHeight,
              ),
              const SizedBox(height: 10),
              FilledButton.icon(
                key: const Key('calculateBmi'),
                onPressed: _calculateBmi,
                icon: const Icon(Icons.monitor_weight_outlined),
                label: const Text('Tính BMI'),
              ),
              const SizedBox(height: 12),
              _resultPanel(
                key: const Key('bmiResult'),
                text: _bmiValue,
                color: _bmiColor,
              ),
              const SizedBox(height: 8),
              Container(
                key: const Key('bmiCategory'),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: _bmiColor.withValues(alpha: 0.09),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _bmiCategory,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: _bmiColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Phân loại tham khảo theo ngưỡng BMI cho người châu Á (WHO): '
                'thiếu cân < 18,5; bình thường 18,5–22,9; thừa cân 23–24,9; '
                'béo phì ≥ 25.',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _sectionCard(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(icon, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }

  Widget _numberField({
    required Key key,
    required TextEditingController controller,
    required FocusNode focusNode,
    required String label,
    String? errorText,
    bool signed = false,
  }) {
    return TextField(
      key: key,
      controller: controller,
      focusNode: focusNode,
      keyboardType: TextInputType.numberWithOptions(
        decimal: true,
        signed: signed,
      ),
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(labelText: label, errorText: errorText),
      onChanged: (_) {
        if (errorText != null) {
          setState(() {
            if (focusNode == _focusA) {
              _errorA = null;
            } else if (focusNode == _focusB) {
              _errorB = null;
            } else if (focusNode == _focusWeight) {
              _errorWeight = null;
            } else {
              _errorHeight = null;
            }
          });
        }
      },
    );
  }

  Widget _operationButton(String label, VoidCallback onPressed) {
    return SizedBox(
      width: 68,
      child: FilledButton.tonal(
        key: Key('operation$label'),
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _resultPanel({
    required Key key,
    required String text,
    required Color color,
  }) {
    return Container(
      key: key,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.28)),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.titleMedium
            ?.copyWith(color: color, fontWeight: FontWeight.bold),
      ),
    );
  }
}
