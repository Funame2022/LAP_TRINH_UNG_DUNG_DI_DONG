enum BmiCategory {
  underweight('Thiếu cân'),
  normal('Bình thường'),
  overweight('Thừa cân'),
  obese('Béo phì');

  const BmiCategory(this.label);

  final String label;
}

double? parseLocalizedNumber(String input) {
  final String trimmed = input.trim();
  if (trimmed.isEmpty ||
      !RegExp(r'^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][+-]?\d+)?$')
          .hasMatch(trimmed)) {
    return null;
  }
  return double.tryParse(trimmed.replaceAll(',', '.'));
}

double calculateBmi(double weightKg, double heightMetersOrCentimeters) {
  final double heightMeters = heightMetersOrCentimeters > 3
      ? heightMetersOrCentimeters / 100
      : heightMetersOrCentimeters;
  return weightKg / (heightMeters * heightMeters);
}

BmiCategory classifyBmi(double bmi) {
  if (bmi < 18.5) {
    return BmiCategory.underweight;
  }
  if (bmi < 23) {
    return BmiCategory.normal;
  }
  if (bmi < 25) {
    return BmiCategory.overweight;
  }
  return BmiCategory.obese;
}
