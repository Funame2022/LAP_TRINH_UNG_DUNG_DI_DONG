# A4_231A010025 — Máy tính và BMI

Ứng dụng Flutter thực hành xử lý sự kiện, nhập liệu và kiểm tra dữ liệu theo
Lab A4. Các phép tính và BMI được xử lý cục bộ trong ứng dụng; dữ liệu nhập
không được lưu.

## Chạy ứng dụng

```powershell
flutter pub get
flutter run -d emulator-5554
```

## Kiểm tra chất lượng

```powershell
flutter test
flutter analyze
flutter build apk --debug
```

## Nội dung

- Máy tính cộng, trừ, nhân, chia với số thực; hiển thị kết quả theo locale
  `vi_VN`.
- Kiểm tra dữ liệu rỗng, sai định dạng, không hữu hạn và lỗi theo nghiệp vụ.
- BMI nhận chiều cao mét hoặc centimet; phân loại theo ngưỡng BMI châu Á:
  thiếu cân `< 18.5`, bình thường `18.5–22.9`, thừa cân `23–24.9`, béo phì
  `>= 25`.
- NC1: nút đảo dấu `±` và chuyển giá trị ô A thành phần trăm (`A / 100`).
- NC3: tô màu kết quả BMI theo phân loại.

Giao diện được triển khai bằng Flutter/Dart theo yêu cầu dự án. Vì vậy các
`EditText`/`setError`/`Toast` trong hướng dẫn Java/XML được ánh xạ sang
`TextField`, lỗi inline và `SnackBar` của Flutter. Phép tính và kiểm tra dữ
liệu được tách thành các hàm Dart để dễ kiểm thử.

## Báo cáo và minh chứng

- Báo cáo Word: `docs/Lab_A4_BaoCao.docx`
- Video quay AVD: `docs/evidence/Lab_A4_Demo.mp4` (thời lượng được kiểm tra
  dưới 2 phút)
- Ảnh chụp màn hình: `docs/evidence/`

Thiết bị kiểm thử: Pixel 4 AVD, Android 17 / API 37.
