package vn.edu.vhu.ltdd.a4events

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
