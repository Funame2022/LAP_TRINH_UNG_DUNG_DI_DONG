import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lab_a1_flutter/main.dart';

const MethodChannel activityChannel = MethodChannel(
  'vn.edu.vhu.lab_a1_flutter/activity_lifecycle',
);

void main() {
  final List<MethodCall> methodCalls = <MethodCall>[];

  setUp(() {
    methodCalls.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(activityChannel, (MethodCall call) async {
          methodCalls.add(call);
          return null;
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(activityChannel, null);
  });

  testWidgets('shows the Lab A1 screen and controls', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const LabA1App());
    await tester.pump();

    expect(find.text('Lab A1 – Vòng đời Activity'), findsOneWidget);
    expect(find.text('Nguyễn Thịnh Phú – MSSV 231A010025'), findsOneWidget);
    expect(find.text('Xóa log'), findsOneWidget);
    expect(find.text('Gây lỗi'), findsOneWidget);
    expect(find.text('Thoát'), findsOneWidget);
    expect(find.text('Chưa có sự kiện'), findsOneWidget);
    expect(methodCalls.any((call) => call.method == 'startListening'), isTrue);
  });

  testWidgets('counts and colors native Activity lifecycle callbacks', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const LabA1App());
    await tester.binding.defaultBinaryMessenger.handlePlatformMessage(
      activityChannel.name,
      const StandardMethodCodec().encodeMethodCall(
        MethodCall('lifecycle', <String, Object>{
          'number': 3,
          'timestamp': '12:34:56.789',
          'message': 'onPause',
        }),
      ),
      null,
    );
    await tester.pump();

    expect(find.text('onPause: 1'), findsOneWidget);
    expect(find.text('onPause'), findsOneWidget);
    final Text logMessage = tester.widget<Text>(find.text('onPause'));
    expect(logMessage.style?.color, Colors.deepOrange);
    expect(find.text('3. [12:34:56.789] '), findsOneWidget);
  });

  testWidgets('clears lifecycle events and their counts', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const LabA1App());
    await tester.binding.defaultBinaryMessenger.handlePlatformMessage(
      activityChannel.name,
      const StandardMethodCodec().encodeMethodCall(
        MethodCall('lifecycle', <String, Object>{
          'number': 1,
          'timestamp': '12:34:56.789',
          'message': 'onCreate',
        }),
      ),
      null,
    );
    await tester.pump();
    await tester.tap(find.text('Xóa log'));
    await tester.pumpAndSettle();

    expect(find.text('onCreate'), findsNothing);
    expect(find.text('onCreate: 1'), findsNothing);
    expect(find.text('Chưa có sự kiện'), findsOneWidget);
    expect(methodCalls.any((call) => call.method == 'clearHistory'), isTrue);
  });

  testWidgets('delegates safe null-error handling to Android', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const LabA1App());
    await tester.tap(find.text('Gây lỗi'));
    await tester.pump();

    expect(methodCalls.any((call) => call.method == 'handleNullError'), isTrue);
    expect(tester.takeException(), isNull);
  });
}
