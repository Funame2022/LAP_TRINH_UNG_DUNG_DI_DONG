package vn.edu.vhu.lab_a1_flutter

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "vn.edu.vhu.lab_a1_flutter/activity_lifecycle"
        private const val TAG = "A1_231A010025"
    }

    private var lifecycleChannel: MethodChannel? = null
    private val pendingEvents = mutableListOf<Map<String, Any>>()
    private var isListening = false
    private var step = 0

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        lifecycleChannel =
            MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        lifecycleChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "startListening" -> {
                    isListening = true
                    pendingEvents.toList().forEach(::sendEvent)
                    pendingEvents.clear()
                    result.success(null)
                }
                "clearHistory" -> {
                    step = 0
                    Log.i(TAG, "---- Đã xóa lịch sử ----")
                    result.success(null)
                }
                "handleNullError" -> {
                    try {
                        val name: String? = null
                        Log.d(TAG, "Độ dài tên: ${name!!.length}")
                    } catch (error: NullPointerException) {
                        Log.e(TAG, "Bắt được lỗi NullPointerException", error)
                        Toast.makeText(
                            this,
                            "Đã bắt lỗi: tên đang null",
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun logLifecycle(event: String) {
        step++
        val timestamp =
            SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        val line = "$step. [$timestamp] $event"
        Log.d(TAG, line)

        val payload = mapOf(
            "number" to step,
            "timestamp" to timestamp,
            "message" to event,
        )
        if (isListening) {
            sendEvent(payload)
        } else {
            pendingEvents.add(payload)
        }
    }

    private fun sendEvent(payload: Map<String, Any>) {
        lifecycleChannel?.invokeMethod("lifecycle", payload)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val state = if (savedInstanceState == null) "= null" else "!= null"
        logLifecycle("onCreate (savedInstanceState $state)")
    }

    override fun onStart() {
        super.onStart()
        logLifecycle("onStart")
    }

    override fun onResume() {
        super.onResume()
        logLifecycle("onResume")
    }

    override fun onPause() {
        super.onPause()
        logLifecycle("onPause")
    }

    override fun onStop() {
        super.onStop()
        logLifecycle("onStop")
    }

    override fun onRestart() {
        super.onRestart()
        logLifecycle("onRestart")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        logLifecycle("onSaveInstanceState")
    }

    override fun onDestroy() {
        logLifecycle("onDestroy")
        super.onDestroy()
    }
}
