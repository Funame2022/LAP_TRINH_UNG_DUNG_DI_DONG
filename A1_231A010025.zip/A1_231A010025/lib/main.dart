import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const LabA1App());
}

class LabA1App extends StatelessWidget {
  const LabA1App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'A1_231A010025',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B63)),
        useMaterial3: true,
      ),
      home: const LifecyclePage(),
    );
  }
}

class LifecyclePage extends StatefulWidget {
  const LifecyclePage({super.key});

  @override
  State<LifecyclePage> createState() => _LifecyclePageState();
}

class _LifecyclePageState extends State<LifecyclePage> {
  static const MethodChannel _activityChannel = MethodChannel(
    'vn.edu.vhu.lab_a1_flutter/activity_lifecycle',
  );
  static const String _student = 'Nguyễn Thịnh Phú – MSSV 231A010025';

  final List<_LifecycleEvent> _events = <_LifecycleEvent>[];
  final Map<String, int> _counts = <String, int>{};
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _activityChannel.setMethodCallHandler(_handleActivityMessage);
    WidgetsBinding.instance.addPostFrameCallback((_) => _startListening());
  }

  Future<void> _startListening() async {
    try {
      await _activityChannel.invokeMethod<void>('startListening');
    } on PlatformException catch (error, stackTrace) {
      debugPrint('Không thể nhận callback Activity: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        _addLocalEvent(
          'Lỗi kết nối Android: ${error.message ?? error.code}',
          isError: true,
        );
      }
    } on MissingPluginException catch (error, stackTrace) {
      debugPrint('Android lifecycle bridge không khả dụng: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        _addLocalEvent('Không tìm thấy Android lifecycle bridge.', isError: true);
      }
    }
  }

  Future<void> _handleActivityMessage(MethodCall call) async {
    if (call.method != 'lifecycle') {
      throw MissingPluginException(
        'Unsupported Android callback: ${call.method}',
      );
    }

    final Object? arguments = call.arguments;
    if (arguments is! Map<Object?, Object?>) {
      throw PlatformException(
        code: 'INVALID_CALLBACK',
        message: 'Android lifecycle callback payload must be a map.',
      );
    }
    final Object? number = arguments['number'];
    final Object? timestamp = arguments['timestamp'];
    final Object? message = arguments['message'];
    if (number is! int || timestamp is! String || message is! String) {
      throw PlatformException(
        code: 'INVALID_CALLBACK',
        message:
            'Android lifecycle callback payload is missing required fields.',
      );
    }
    if (!mounted) {
      return;
    }

    setState(() {
      _events.add(
        _LifecycleEvent(
          number: number.toString(),
          timestamp: timestamp,
          message: message,
        ),
      );
      _counts.update(message, (count) => count + 1, ifAbsent: () => 1);
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _addLocalEvent(String message, {bool isError = false}) {
    final DateTime now = DateTime.now();
    final String timestamp =
        '${now.hour.toString().padLeft(2, '0')}:'
        '${now.minute.toString().padLeft(2, '0')}:'
        '${now.second.toString().padLeft(2, '0')}.'
        '${now.millisecond.toString().padLeft(3, '0')}';
    setState(() {
      _events.add(
        _LifecycleEvent(
          number: '•',
          timestamp: timestamp,
          message: message,
          isError: isError,
        ),
      );
    });
    _scrollToBottom();
  }

  @override
  void dispose() {
    _activityChannel.setMethodCallHandler(null);
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _clearLogs() async {
    setState(() {
      _events.clear();
      _counts.clear();
    });
    try {
      await _activityChannel.invokeMethod<void>('clearHistory');
    } on PlatformException catch (error, stackTrace) {
      debugPrint('Không thể xóa lịch sử Activity: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        _addLocalEvent(
          'Lỗi khi xóa log Android: ${error.message ?? error.code}',
          isError: true,
        );
      }
    } on MissingPluginException catch (error, stackTrace) {
      debugPrint('Android lifecycle bridge không khả dụng: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        _addLocalEvent('Không tìm thấy Android lifecycle bridge.', isError: true);
      }
    }
  }

  Future<void> _handleNullError() async {
    try {
      await _activityChannel.invokeMethod<void>('handleNullError');
    } on PlatformException catch (error, stackTrace) {
      debugPrint('Không thể xử lý lỗi null native: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        _addLocalEvent(
          'Lỗi khi kiểm tra null: ${error.message ?? error.code}',
          isError: true,
        );
      }
    } on MissingPluginException catch (error, stackTrace) {
      debugPrint('Android lifecycle bridge không khả dụng: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        _addLocalEvent('Không tìm thấy Android lifecycle bridge.', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                'Lab A1 – Vòng đời Activity',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              const Text(_student),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _clearLogs,
                      child: const Text('Xóa log'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _handleNullError,
                      child: const Text('Gây lỗi'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: SystemNavigator.pop,
                      child: const Text('Thoát'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Lịch sử callback Activity',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              if (_counts.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 2,
                    children: _counts.entries
                        .map(
                          (entry) => Chip(
                            label: Text('${entry.key}: ${entry.value}'),
                            visualDensity: VisualDensity.compact,
                          ),
                        )
                        .toList(),
                  ),
                ),
              const SizedBox(height: 8),
              Expanded(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: colors.surfaceContainerHighest.withValues(
                      alpha: 0.35,
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _events.isEmpty
                      ? const Center(child: Text('Chưa có sự kiện'))
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.all(8),
                          itemCount: _events.length,
                          itemBuilder: (context, index) {
                            final _LifecycleEvent event = _events[index];
                            final Color? lineColor = event.isError
                                ? colors.error
                                : switch (event.message) {
                                    'onPause' || 'onStop' => Colors.deepOrange,
                                    'onDestroy' => colors.error,
                                    _ => null,
                                  };
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 3),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    '${event.number}. [${event.timestamp}] ',
                                    style: const TextStyle(
                                      fontFamily: 'monospace',
                                      fontSize: 14,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      event.message,
                                      style: TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 14,
                                        color: lineColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LifecycleEvent {
  const _LifecycleEvent({
    required this.number,
    required this.timestamp,
    required this.message,
    this.isError = false,
  });

  final String number;
  final String timestamp;
  final String message;
  final bool isError;
}
