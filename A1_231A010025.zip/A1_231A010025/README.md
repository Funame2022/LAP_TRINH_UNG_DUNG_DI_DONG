# Lab A1 – Vòng đời Activity (Flutter)

Đây là bản chuyển Lab A1 Java/XML sang Flutter, chạy trên Android emulator.

## Phần 4 – Xây dựng ứng dụng

- `lib/main.dart` dựng giao diện thay cho `activity_main.xml`, gồm tiêu đề,
  thông tin sinh viên, ba nút, bộ đếm callback và danh sách log có thể cuộn.
- `android/app/src/main/kotlin/vn/edu/vhu/lab_a1_flutter/MainActivity.kt`
  override các callback Activity, ghi Logcat và gửi callback sang Flutter bằng
  `MethodChannel`.
- `android/app/src/main/res/values/strings.xml` đặt tên ứng dụng trên Android.
- Tag Logcat và thông tin sinh viên hiện dùng `231A010025`. Sửa tag trong
  `MainActivity.kt`, thông tin trong `main.dart` và app name trong `strings.xml`
  nếu cần dùng mã khác.

Mở AVD từ Android Studio **Tools > Device Manager**, sau đó chạy:

```powershell
cd G:\lab_a1_flutter
G:\flutter\bin\flutter.bat devices
G:\flutter\bin\flutter.bat run -d <emulator-id>
```

Trong Android Studio Logcat lọc bằng `tag:A1_231A010025`. Lần khởi chạy đầu
thường có `onCreate`, `onStart`, `onResume`.

## Phần 5 – Sáu kịch bản vòng đời

Trước mỗi kịch bản, nhấn **Xóa log** trong app và xóa log cũ trong Logcat.
Ghi chuỗi thực tế cùng phiên bản API của AVD vào báo cáo; callback có thể khác
theo phiên bản Android, trạng thái tiến trình và thao tác thiết bị.

| # | Thao tác | Callback thường thấy |
|---|---|---|
| 1 | Mở app lần đầu | `onCreate` → `onStart` → `onResume` |
| 2 | Nhấn Home | `onPause` → `onStop` → `onSaveInstanceState` (thứ tự cuối tùy API) |
| 3 | Mở lại từ Recents | Thường `onRestart` → `onStart` → `onResume`; nếu hệ thống đã hủy process thì app tạo Activity mới |
| 4 | Bật xoay tự động rồi xoay màn hình | Activity được tạo lại: pause/stop/save/destroy rồi create với state khác null/start/resume. Lịch sử trên màn hình có thể bắt đầu lại, Logcat vẫn lưu các dòng trước đó |
| 5 | Nhấn **Thoát** | `onPause` → `onStop` → `onDestroy` (tùy thời điểm hệ thống) |
| 6 | Mở lại app rồi nhấn Back | Ghi lại điều thực tế; Android 12 trở lên có thể đưa app launcher về nền mà không gọi `onDestroy` ngay |

Manifest cố ý không khai báo `orientation` và `screenSize` trong `configChanges`
để phép xoay tạo lại Activity, phù hợp thí nghiệm của bài. Flutter framework có
thể khởi tạo lại giao diện trong lần tạo Activity mới; Logcat là nguồn đối chiếu
các callback native.

Các câu phân tích cần trả lời trong báo cáo:

1. Vì sao sau khi xoay, lịch sử trong app có thể mất nhưng Logcat vẫn còn?
2. `savedInstanceState` trong lần `onCreate` sau khi xoay có null không, và nó
   cho biết điều gì?
3. Vì sao Back trên Android 12+ có thể chưa gọi `onDestroy` ngay?
4. Nên lưu dữ liệu đang nhập ở callback nào, và vì sao không nên đợi
   `onDestroy`?

## Phần 6 – Đọc lỗi crash trong Logcat

Phiên bản nộp hiện tại đã áp dụng cách sửa NC2: nút **Gây lỗi** tạo lỗi null,
bắt `NullPointerException`, ghi stack trace bằng `Log.e` và hiện Toast; app
không bị crash.

Để quan sát crash đúng yêu cầu Phần 6, chỉ trên bản thử nghiệm: trong
`MainActivity.kt`, tìm nhánh `handleNullError` và tạm thay phần `try/catch` bằng
đoạn sau, chạy app rồi nhấn **Gây lỗi**:

```kotlin
val name: String? = null
Log.d(TAG, "Độ dài tên: ${name!!.length}")
result.success(null)
```

Trong Logcat lọc `package:mine level:error`, tìm `FATAL EXCEPTION` và dòng đầu
của stack trace thuộc package ứng dụng. Lỗi cố ý này sẽ dừng app. Sau khi chụp
ảnh/ghi chú, khôi phục nhánh `handleNullError` có `try/catch` như ban đầu và
chạy lại để xác nhận Toast xuất hiện mà app vẫn hoạt động. Không nộp bản còn
đoạn cố ý crash nếu muốn giữ NC2.

## Phần 7 – Bài nâng cao đã làm

- **NC1:** đếm số lần mỗi callback và hiển thị số đếm phía trên vùng log.
- **NC2:** bắt lỗi null native, ghi lỗi vào Logcat và hiện Toast thay vì crash.
- **NC3:** tô cam cho `onPause`/`onStop`, đỏ cho `onDestroy` và lỗi.

Phần 7 yêu cầu tối thiểu hai bài nâng cao; phiên bản này đã làm ba bài trên.
NC4 (Activity thứ hai) không được thêm vì đây là nội dung mở rộng riêng.

## Phần 8 – Hướng dẫn nộp bài

### 1. Chuẩn bị project zip

1. Xác nhận app chạy trên AVD và bản cuối đã khôi phục xử lý lỗi an toàn.
2. Trong terminal dự án chạy `G:\flutter\bin\flutter.bat clean` để xóa output
   build được sinh tự động. Lệnh này không xóa mã nguồn.
3. Đóng Android Studio rồi nén thư mục `G:\lab_a1_flutter` thành
   `A1_231A010025.zip` (đổi tên theo MSSV nếu cần).
4. Không đưa `build/`, `.dart_tool/` hoặc `android/.gradle/` vào zip. Giữ lại
   `lib/`, `android/`, `test/`, `pubspec.yaml`, `pubspec.lock`, README và các
   file cấu hình dự án để người chấm có thể build lại.

### 2. Báo cáo Word/PDF

- Trang bìa: họ tên, MSSV, lớp, phiên bản Android Studio, tên AVD/điện thoại và
  phiên bản Android/API.
- Ảnh checkpoint ban đầu theo yêu cầu lớp; ảnh checkpoint Phần 4 gồm màn hình
  app và Logcat đã lọc theo tag.
- Bảng sáu kịch bản Phần 5: thao tác, callback mong đợi, callback quan sát
  thực tế và ảnh Logcat riêng cho từng kịch bản.
- Trả lời câu hỏi Phần 3 và bốn câu hỏi phân tích Phần 5.
- Mô tả NC1, NC2, NC3 đã làm, kèm ảnh và đoạn code chính.
- Dùng MSSV của chính bạn trong tên project/app và tag Logcat theo yêu cầu môn.

### 3. Video demo

Tạo video tối đa 2 phút, quay đồng thời máy ảo và Logcat. Mở app, thực hiện ít
nhất kịch bản 2 (Home), 4 (xoay màn hình), 5 (Thoát), giải thích callback xuất
hiện và chia sẻ qua Google Drive/YouTube ở chế độ không công khai. Dán link vào
báo cáo hoặc LMS theo yêu cầu lớp.

Hạn nộp trong tài liệu lab là 23:59, ba ngày sau buổi lab; hãy đối chiếu lại
thông báo mới nhất trên LMS.

## Kiểm tra trước khi nộp

```powershell
G:\flutter\bin\flutter.bat test
G:\flutter\bin\flutter.bat analyze
G:\flutter\bin\flutter.bat build apk --debug
```
