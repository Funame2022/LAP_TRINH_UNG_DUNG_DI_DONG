# Lab F1 – Flutter & Dart cơ bản

Project Flutter mới cho Lab F1, độc lập với `G:\lab_a1_flutter` (Lab A1).
Tên project là `f1_hello`; ứng dụng hiển thị `F1_231A010025`.

## Thông tin hồ sơ

- Họ tên: Nguyễn Thịnh Phú
- MSSV: 231A010025
- Lớp: 231A29032

Nếu thông tin này chưa chính xác, sửa các hằng `studentName`, `studentId`,
`className` trong `lib/main.dart`.

## Phần 1 – Môi trường Flutter

Đã kiểm tra môi trường trên máy này bằng `flutter doctor`: Flutter stable,
Android toolchain, Visual Studio, Chrome, thiết bị và network đều đạt. AVD
hiện có là `emulator-5554`, Android 17 / API 37.

Chạy lại kiểm tra trên máy của bạn:

```powershell
G:\flutter\bin\flutter.bat --version
G:\flutter\bin\flutter.bat doctor
G:\flutter\bin\flutter.bat doctor --android-licenses
```

Lưu ảnh kết quả `flutter doctor` để đưa vào báo cáo.

## Phần 2 – Năm bài Dart trên DartPad

Mở <https://dartpad.dev>, tạo một DartPad mới cho mỗi bài, dán nội dung file
tương ứng trong `tool/dart_exercises/`, bấm **Run**, rồi chụp ảnh Console.
Mỗi file là một chương trình độc lập và có thể dán thẳng vào DartPad; bài 5
cũng tự khai báo lớp `SinhVien`, không cần import file bài 4:

1. `variables_null_safety.dart`
2. `named_parameters_bmi.dart`
3. `lists_higher_order.dart`
4. `class_getter.dart`
5. `map_grade_counts.dart`

Các đáp án chính:

- Bài 1: `var` suy luận kiểu nhưng có thể gán lại đúng kiểu; `final` chỉ gán một
  lần lúc chạy; `const` là hằng lúc biên dịch. Gán `ten = 10` lỗi kiểu lúc biên
  dịch; gán `namHoc = 2027` lỗi vì `final` không gán lại. `biDanh!.length` ném
  lỗi runtime (`Null check operator used on a null value`) vì biến đang null.
- Bài 2: tham số có tên có thể truyền theo thứ tự bất kỳ; tên tham số xác định
  giá trị được gán vào nên kết quả BMI vẫn là 20.8.
- Bài 3–5: các file chứa lời giải có thể chạy được; đầu ra kỳ vọng lần lượt:
  trung bình 6.90 và danh sách điểm đạt; hai đối tượng sinh viên; map
  `{Giỏi: 1, Trung bình: 1}`.

Có thể chạy lại năm lời giải bằng Dart từ terminal:

```powershell
cd G:\f1_hello
dart run tool\dart_exercises\variables_null_safety.dart
dart run tool\dart_exercises\named_parameters_bmi.dart
dart run tool\dart_exercises\lists_higher_order.dart
dart run tool\dart_exercises\class_getter.dart
dart run tool\dart_exercises\map_grade_counts.dart
```

## Phần 3 – Project và Hot Reload / Hot Restart

Project được tạo bằng:

```powershell
cd G:\
G:\flutter\bin\flutter.bat create --org vn.edu.vhu.ltdd f1_hello
```

Ứng dụng hồ sơ chính nằm ở `lib/main.dart`. Để chạy lại ứng dụng đếm mẫu cho
thí nghiệm Hot Reload/Hot Restart trước khi làm app hồ sơ:

```powershell
cd G:\f1_hello
G:\flutter\bin\flutter.bat run -d emulator-5554 -t lib\counter_demo.dart
```

1. Nhấn `+` khoảng 5 lần.
2. Đổi `Colors.deepPurple` thành `Colors.teal` trong `lib/counter_demo.dart`,
   lưu file hoặc bấm **Hot Reload**. Màu đổi; số đếm cần giữ nguyên.
3. Nhấn **Hot Restart** trong IDE (hoặc `R` ở terminal Flutter). State app khởi
   tạo lại, số đếm về 0.
4. Mở `lib/main.dart` làm thí nghiệm tương tự với hồ sơ: nhấn Thích 5 lần, đổi
   `Colors.indigo` sang `Colors.teal`, Hot Reload; sau đó đổi `_likes = 0` thành
   `_likes = 3`, lưu và quan sát giá trị state đang chạy; Hot Restart sẽ chạy
   lại `initState`, tạo lượt thích ban đầu theo source mới.
5. Với mỗi bước, ghi kết quả **thực tế** vào bảng báo cáo; Hot Reload/Restart
   phải thao tác trong phiên chạy tương tác của IDE/Flutter CLI.

Mã `lib/counter_demo.dart` giữ riêng ví dụ đếm mẫu để có thể mở lại thí nghiệm.

## Phần 4 – Ứng dụng “Hồ sơ của tôi”

`lib/main.dart` thực hiện app hồ sơ với AppBar, lượt thích, giảm (không âm),
Thích, đặt lại, đổi chữ đỏ khi lượt thích từ 10 trở lên và danh sách kỹ năng.
`ProfileCard` là `StatelessWidget` riêng trong
`lib/widgets/profile_card.dart`; trang tương tác là `StatefulWidget` và mọi
thay đổi state đều gọi `setState`.

Chạy trên AVD:

```powershell
cd G:\f1_hello
G:\flutter\bin\flutter.bat devices
G:\flutter\bin\flutter.bat run -d emulator-5554
```

Nếu ID thiết bị khác, thay bằng ID được `flutter devices` liệt kê. Mở dự án
trong Android Studio bằng **File > Open > `G:\f1_hello`**; chọn thư mục có
`pubspec.yaml`, không chọn thư mục Flutter SDK `G:\flutter`.

### Thí nghiệm Hot Reload/Hot Restart

| # | Thao tác | Kết quả cần kiểm tra | Kết quả quan sát |
|---|---|---|---|
| 1 | Nhấn Thích 5 lần | Lượt thích = 5 | [GHI KẾT QUẢ] |
| 2 | Đổi màu seed sang teal, Hot Reload | Màu đổi, lượt thích vẫn 5 | [GHI KẾT QUẢ] |
| 3 | Đổi giá trị khởi tạo `_likes` thành 3, Hot Reload | State đang chạy thường vẫn giữ giá trị hiện tại | [GHI KẾT QUẢ] |
| 4 | Hot Restart | App chạy lại từ đầu; lượt thích khởi tạo thành 3 nếu source đang để 3 | [GHI KẾT QUẢ] |
| 5 | Xoay màn hình | Quan sát state và Flutter/Android lifecycle trên thiết bị | [GHI KẾT QUẢ] |

Sau thí nghiệm, trả source về `_likes = 0` và `Colors.indigo` trước khi chụp
ảnh nộp hoặc build bản cuối.

## Phần 5 – Bài nâng cao

Đã triển khai cả bốn bài:

- **NC1:** nút trên AppBar chuyển Light/Dark theme.
- **NC2:** 5 FilterChip kỹ năng Java, Dart, SQL, Git, UI/UX; trạng thái chọn lưu
  trong `Set<String>` và hiển thị số kỹ năng đã chọn.
- **NC3:** `AppLifecycleListener` ghi `initState`, `AppLifecycleState` và
  `dispose` ra Debug Console. Đối chiếu gần đúng: resumed/onResume,
  inactive/onPause, hidden/paused/onStop; các khái niệm không hoàn toàn tương
  đương vì một bên là vòng đời Flutter, một bên là Android Activity.
- **NC4:** `ProfileCard` được tách ra `lib/widgets/profile_card.dart`.

## Phần 6 – Nộp bài

1. Chạy kiểm tra:

   ```powershell
   cd G:\f1_hello
   G:\flutter\bin\flutter.bat test
   G:\flutter\bin\flutter.bat analyze
   G:\flutter\bin\flutter.bat build apk --debug
   ```

2. Chụp ảnh Checkpoint 1 (`flutter doctor`), Checkpoint 2 (app có lượt thích từ
   10 trở lên, chữ đỏ), Console của 5 bài Dart và các bước Hot Reload/Hot
   Restart. Điền kết quả thực tế vào bảng.
3. Tạo báo cáo Word/PDF theo danh sách ở mục 7 của hướng dẫn; bao gồm phần thử
   thêm Bài 1–2 và mô tả ít nhất hai bài nâng cao.
4. Chạy `G:\flutter\bin\flutter.bat clean`, sau đó nén `lib/` và
   `pubspec.yaml` thành `F1_231A010025.zip` (hoặc nén toàn project đã clean).
   Không đưa `build/` hay `.dart_tool/` vào ZIP. Nếu nộp riêng `lib/` và
   `pubspec.yaml`, hãy chắc chắn đã giữ `lib/widgets/profile_card.dart`,
   `lib/counter_demo.dart` và các mã nguồn cần thiết.
5. Quay video ≤ 2 phút có giọng thuyết minh, thể hiện Thích/giảm/đặt lại, một
   lần Hot Reload và một lần Hot Restart; tải lên nơi chia sẻ không công khai
   và nộp link theo LMS.

Hạn theo tài liệu: 23:59, ba ngày sau buổi lab; đối chiếu thông báo LMS.

## Phần 8 – Câu hỏi ôn tập và gợi ý trả lời

1. **`var`, `final`, `const`:** `var` là khai báo có suy luận kiểu và có thể
   gán lại; `final` chỉ gán một lần lúc chạy; `const` là hằng compile-time.
2. **Null safety:** hạn chế lỗi truy cập giá trị null. `?` cho phép nullable;
   `?.` gọi/truy cập an toàn; `??` cung cấp giá trị thay thế khi null; `!`
   khẳng định non-null và gây lỗi runtime nếu thực tế null.
3. **Stateless/Stateful:** dùng StatelessWidget khi UI chỉ phụ thuộc dữ liệu
   đầu vào bất biến; dùng StatefulWidget khi widget cần giữ state thay đổi.
   Không gọi `setState` thì Flutter không được yêu cầu rebuild nên UI có thể
   chưa phản ánh giá trị mới.
4. **Hot Reload/Hot Restart:** Hot Reload nạp thay đổi code và giữ state đang
   sống; Hot Restart khởi động lại isolate/app Dart và reset state trong RAM.
   Thay đổi native Android/iOS, dependencies hoặc một số thay đổi khởi tạo
   cần full restart/rebuild.
5. **Lab A1 XML + Java và Lab F1 Flutter:** A1 mô tả layout tĩnh trong XML,
   truy cập view bằng ID và cập nhật thủ công; Flutter dựng UI bằng cây widget
   Dart và UI được render lại theo state. A1 dùng Activity/Android lifecycle;
   Flutter quản lý widget/state lifecycle và có lớp Android host bên dưới.

## Môi trường đã xác nhận

- Flutter stable 3.47.5; Dart 3.13.4.
- Android toolchain / Android SDK 37.0.0.
- AVD `emulator-5554`: Android 17 / API 37.
- `flutter doctor`: không có lỗi trên máy khi kiểm tra.
