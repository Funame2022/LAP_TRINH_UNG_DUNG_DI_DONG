import 'package:flutter/material.dart';

import 'widgets/profile_card.dart';

const String studentName = 'Nguyễn Thịnh Phú';
const String studentId = '231A010025';
const String className = '231A29032';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _mode = ThemeMode.light;

  void _toggleTheme() {
    setState(() {
      _mode = _mode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'F1_$studentId',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: _mode,
      home: ProfilePage(
        isDarkMode: _mode == ThemeMode.dark,
        onToggleTheme: _toggleTheme,
      ),
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({
    super.key,
    required this.isDarkMode,
    required this.onToggleTheme,
  });

  final bool isDarkMode;
  final VoidCallback onToggleTheme;

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  static const List<String> _skills = <String>[
    'Java',
    'Dart',
    'SQL',
    'Git',
    'UI/UX',
  ];

  int _likes = 0;
  final Set<String> _selectedSkills = <String>{};
  late final AppLifecycleListener _listener;

  @override
  void initState() {
    super.initState();
    debugPrint('[F1] initState');
    _listener = AppLifecycleListener(
      onStateChange: (state) {
        debugPrint('[F1] AppLifecycleState: ${state.name}');
      },
    );
  }

  @override
  void dispose() {
    _listener.dispose();
    debugPrint('[F1] dispose');
    super.dispose();
  }

  void _increase() {
    setState(() {
      _likes++;
    });
  }

  void _decrease() {
    if (_likes == 0) {
      return;
    }
    setState(() {
      _likes--;
    });
  }

  void _reset() {
    setState(() {
      _likes = 0;
    });
  }

  void _toggleSkill(String skill, bool selected) {
    setState(() {
      if (selected) {
        _selectedSkills.add(skill);
      } else {
        _selectedSkills.remove(skill);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color likeColor = _likes >= 10 ? Colors.red : scheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab F1 – Hồ sơ của tôi'),
        backgroundColor: scheme.primaryContainer,
        actions: <Widget>[
          IconButton(
            key: const ValueKey<String>('theme-toggle'),
            tooltip: widget.isDarkMode ? 'Chế độ sáng' : 'Chế độ tối',
            onPressed: widget.onToggleTheme,
            icon: Icon(
              widget.isDarkMode ? Icons.light_mode : Icons.dark_mode,
            ),
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const ProfileCard(
                name: studentName,
                studentId: studentId,
                className: className,
              ),
              const SizedBox(height: 24),
              Text(
                'Lượt thích: $_likes',
                key: const ValueKey<String>('likes-count'),
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: likeColor,
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  IconButton.filledTonal(
                    key: const ValueKey<String>('decrease-likes'),
                    tooltip: 'Giảm lượt thích',
                    onPressed: _decrease,
                    icon: const Icon(Icons.remove),
                  ),
                  const SizedBox(width: 12),
                  FilledButton.icon(
                    key: const ValueKey<String>('increase-likes'),
                    onPressed: _increase,
                    icon: const Icon(Icons.favorite),
                    label: const Text('Thích'),
                  ),
                  const SizedBox(width: 12),
                  IconButton.outlined(
                    key: const ValueKey<String>('reset-likes'),
                    tooltip: 'Đặt lại',
                    onPressed: _reset,
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Kỹ năng',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 4,
                children: _skills.map((skill) {
                  return FilterChip(
                    label: Text(skill),
                    selected: _selectedSkills.contains(skill),
                    onSelected: (selected) => _toggleSkill(skill, selected),
                  );
                }).toList(),
              ),
              const SizedBox(height: 8),
              Text('Đã chọn: ${_selectedSkills.length} kỹ năng'),
            ],
          ),
        ),
      ),
    );
  }
}
