import 'package:flutter/material.dart';

class ProfileCard extends StatelessWidget {
  const ProfileCard({
    super.key,
    required this.name,
    required this.studentId,
    required this.className,
  });

  final String name;
  final String studentId;
  final String className;

  @override
  Widget build(BuildContext context) {
    final String trimmedName = name.trim();
    final List<String> nameParts = trimmedName.isEmpty
        ? <String>[]
        : trimmedName.split(RegExp(r'\s+'));
    final String initial = nameParts.isEmpty ? '?' : nameParts.last[0];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: <Widget>[
            CircleAvatar(
              radius: 40,
              child: Text(initial, style: const TextStyle(fontSize: 32)),
            ),
            const SizedBox(height: 12),
            Text(name, style: Theme.of(context).textTheme.titleLarge),
            Text('MSSV: $studentId'),
            Text('Lớp: $className'),
          ],
        ),
      ),
    );
  }
}
