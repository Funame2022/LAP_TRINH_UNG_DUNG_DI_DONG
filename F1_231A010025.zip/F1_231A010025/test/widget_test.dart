import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:f1_hello/main.dart';

void main() {
  testWidgets('shows the student profile and skills', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Lab F1 – Hồ sơ của tôi'), findsOneWidget);
    expect(find.text('Nguyễn Thịnh Phú'), findsOneWidget);
    expect(find.text('MSSV: 231A010025'), findsOneWidget);
    expect(find.text('Lớp: 231A29032'), findsOneWidget);
    expect(find.text('Lượt thích: 0'), findsOneWidget);
    expect(find.text('Đã chọn: 0 kỹ năng'), findsOneWidget);
    for (final String skill in <String>['Java', 'Dart', 'SQL', 'Git', 'UI/UX']) {
      expect(find.text(skill), findsOneWidget);
    }
  });

  testWidgets('likes increase, never go below zero, reset, and turn red at 10', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());

    await tester.tap(find.byKey(const ValueKey<String>('decrease-likes')));
    await tester.pump();
    expect(find.text('Lượt thích: 0'), findsOneWidget);

    for (int i = 0; i < 10; i++) {
      await tester.tap(find.byKey(const ValueKey<String>('increase-likes')));
    }
    await tester.pump();

    final Text likesText = tester.widget<Text>(
      find.byKey(const ValueKey<String>('likes-count')),
    );
    expect(likesText.data, 'Lượt thích: 10');
    expect(likesText.style?.color, Colors.red);

    await tester.tap(find.byKey(const ValueKey<String>('decrease-likes')));
    await tester.pump();
    expect(find.text('Lượt thích: 9'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey<String>('reset-likes')));
    await tester.pump();
    expect(find.text('Lượt thích: 0'), findsOneWidget);
  });

  testWidgets('toggles between light and dark themes', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());
    expect(tester.widget<MaterialApp>(find.byType(MaterialApp)).themeMode,
        ThemeMode.light);

    await tester.tap(find.byKey(const ValueKey<String>('theme-toggle')));
    await tester.pumpAndSettle();

    expect(tester.widget<MaterialApp>(find.byType(MaterialApp)).themeMode,
        ThemeMode.dark);
  });

  testWidgets('selects and deselects skill chips', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());

    await tester.tap(find.widgetWithText(FilterChip, 'Dart'));
    await tester.pump();
    expect(find.text('Đã chọn: 1 kỹ năng'), findsOneWidget);

    await tester.tap(find.widgetWithText(FilterChip, 'Dart'));
    await tester.pump();
    expect(find.text('Đã chọn: 0 kỹ năng'), findsOneWidget);
  });
}
