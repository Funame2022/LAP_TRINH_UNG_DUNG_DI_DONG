// ignore_for_file: avoid_print

void main() {
  final List<double> diem = <double>[7.5, 4.0, 8.5, 9.0, 5.5];
  final double diemTrungBinh =
      diem.reduce((double a, double b) => a + b) / diem.length;
  final List<double> diemDat = diem.where((double d) => d >= 5).toList();

  print('Điểm TB: ${diemTrungBinh.toStringAsFixed(2)}');
  print('Đạt: $diemDat');
}
