// ignore_for_file: avoid_print

class SinhVien {
  const SinhVien(this.hoTen, this.mssv, this.diemTB);

  final String hoTen;
  final String mssv;
  final double diemTB;

  String get xepLoai {
    if (diemTB >= 8.5) return 'Giỏi';
    if (diemTB >= 7.0) return 'Khá';
    if (diemTB >= 5.0) return 'Trung bình';
    return 'Yếu';
  }

  @override
  String toString() => '$mssv – $hoTen – $diemTB ($xepLoai)';
}

void main() {
  final List<SinhVien> ds = <SinhVien>[
    const SinhVien('Nguyễn Thịnh Phú', '231A010025', 8.7),
    const SinhVien('Trần Thị B', '2201234568', 6.4),
  ];

  for (final SinhVien sv in ds) {
    print(sv);
  }
}
