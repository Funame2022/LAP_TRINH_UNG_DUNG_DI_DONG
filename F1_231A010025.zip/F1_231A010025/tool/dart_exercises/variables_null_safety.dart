// ignore_for_file: avoid_print

void main() {
  String ten = 'Dart';
  final int namHoc = 2026;
  const double pi = 3.14159;

  print('Xin chào $ten! Năm $namHoc, pi = $pi');
  _showAlias(null);

  ten = 'Flutter';
  print('Sau khi đổi ten: $ten');
}

void _showAlias(String? biDanh) {
  print('Bí danh: ${biDanh ?? "(chưa có)"}');
  print('Độ dài bí danh: ${biDanh?.length}');
}
