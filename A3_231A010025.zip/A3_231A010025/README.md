# A3_231A010025 — Lab A3 (Flutter)

Bài thực hành giao diện đăng nhập “Cổng thực hành LTDD”, được triển khai bằng
Flutter/Dart theo yêu cầu của dự án. Hướng dẫn Lab A3 gốc mô tả Java/XML trên
Android; báo cáo đính kèm phân biệt rõ các phần tương đương và khác biệt của
phiên bản Flutter.

## Chạy ứng dụng

Mở thư mục này trong Android Studio/VS Code có Flutter SDK, chạy `flutter pub get`
rồi `flutter run`. Có thể chạy các kiểm tra bằng `flutter test` và
`flutter analyze`.

Báo cáo hoàn chỉnh: [BAO_CAO_LAB_A3_FLUTTER_231A010025.docx](BAO_CAO_LAB_A3_FLUTTER_231A010025.docx).
Ảnh runtime emulator lưu ở `docs/evidence/`; APK debug sinh ra tại
`build/app/outputs/flutter-apk/app-debug.apk`.

## Giao diện

- Màn hình đăng nhập có xác thực đầu vào phía giao diện, hiện Snackbar mô phỏng,
  ghi nhớ đăng nhập, ẩn/hiện mật khẩu và lối tắt chức năng minh họa.
- Ảnh đại diện xếp chồng lên banner; hai ô thống kê chia đều chiều rộng.
- Màn hình tự chuyển sang hai cột khi cửa sổ rộng, đồng thời vẫn cuộn được.
- Chủ đề tự theo hệ thống và có nút chuyển sáng/tối.
- Màn hình phụ minh họa bố cục co giãn bằng `LayoutBuilder`, `Flex` và `Expanded`.

## Thông tin hồ sơ

- Hồ sơ trong `lib/widgets/profile_card.dart` hiện khai báo Nguyễn Thịnh Phú,
  MSSV `231A010025`, lớp `231A29032` và email `phu231a010025@vhu.edu.vn`.
- Các giá trị thống kê `3` lab và `8.5` điểm được khai báo tĩnh trong widget;
  ứng dụng không lấy/kiểm chứng chúng từ hệ thống học vụ.
- Tự vẽ wireframe theo yêu cầu của giảng viên; đối chiếu ảnh runtime trong
  `docs/evidence/` và quay video demo ngắn.
- Tạo/nộp repo GitHub Private, mời giảng viên và push tối thiểu ba commit nếu
  yêu cầu môn học vẫn áp dụng cho phiên bản Flutter.

## Phạm vi đăng nhập

Màn hình xác thực trường bắt buộc và định dạng MSSV chữ-số rồi hiển thị một
Snackbar mô phỏng. Không có dịch vụ xác thực, tài khoản thực, lưu thông tin đăng
nhập hay kết nối backend; quên mật khẩu, đăng nhập trường và đăng ký chỉ hiển
thị thông báo hướng dẫn.
