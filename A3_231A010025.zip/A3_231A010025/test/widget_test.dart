import 'package:a3_231a010025/main.dart';
import 'package:a3_231a010025/widgets/profile_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Shows the login screen and its required form controls', (
    WidgetTester tester,
  ) async {
    tester.view.physicalSize = const Size(1170, 2532);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const A3App());

    expect(find.text('Cổng thực hành LTDD'), findsOneWidget);
    expect(find.text('Đăng nhập hệ thống'), findsOneWidget);
    expect(find.byKey(const Key('studentIdField')), findsOneWidget);
    expect(find.byKey(const Key('passwordField')), findsOneWidget);
    expect(find.byKey(const Key('rememberCheckbox')), findsOneWidget);
    expect(find.byKey(const Key('loginButton')), findsOneWidget);
    expect(find.text(ProfileCard.studentName), findsOneWidget);
  });

  testWidgets('Validates input and confirms a remembered demo login', (
    WidgetTester tester,
  ) async {
    tester.view.physicalSize = const Size(1170, 2532);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const A3App());
    await tester.ensureVisible(find.byKey(const Key('loginButton')));
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pump();

    expect(find.text('Vui lòng nhập mã số sinh viên'), findsOneWidget);
    expect(find.text('Vui lòng nhập mật khẩu'), findsOneWidget);

    await tester.ensureVisible(find.byKey(const Key('rememberCheckbox')));
    await tester.tap(find.byKey(const Key('rememberCheckbox')));
    await tester.pump();

    await tester.enterText(
      find.byKey(const Key('studentIdField')),
      '231 A/010025',
    );
    tester.testTextInput.hide();
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('loginButton')));
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pumpAndSettle();
    expect(find.text('Mã số sinh viên chỉ gồm chữ và số'), findsOneWidget);

    await tester.enterText(
      find.byKey(const Key('studentIdField')),
      ProfileCard.studentId,
    );
    await tester.enterText(find.byKey(const Key('passwordField')), 'lab-a3');
    tester.testTextInput.hide();
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('loginButton')));
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pumpAndSettle();

    expect(
      find.text('Đăng nhập (mô phỏng) thành công · Đã ghi nhớ đăng nhập'),
      findsOneWidget,
    );
  });

  testWidgets('Adapts between narrow and wide layouts', (
    WidgetTester tester,
  ) async {
    tester.view.physicalSize = const Size(1170, 2532);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const A3App());
    expect(find.byKey(const Key('portraitLoginLayout')), findsOneWidget);

    tester.view.physicalSize = const Size(2700, 1170);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('wideLoginLayout')), findsOneWidget);
  });

  testWidgets('Opens the responsive layout comparison screen', (
    WidgetTester tester,
  ) async {
    tester.view.physicalSize = const Size(1170, 2532);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const A3App());
    await tester.ensureVisible(find.byKey(const Key('comparisonButton')));
    await tester.tap(find.byKey(const Key('comparisonButton')));
    await tester.pumpAndSettle();

    expect(find.text('Ví dụ bố cục thích ứng'), findsOneWidget);
    expect(
      find.textContaining('Flutter không có widget ConstraintLayout'),
      findsOneWidget,
    );
  });

  testWidgets('Toggles theme and password visibility', (
    WidgetTester tester,
  ) async {
    tester.view.physicalSize = const Size(1170, 2532);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const A3App());
    final Brightness initialBrightness = Theme.of(
      tester.element(find.byType(Scaffold).first),
    ).brightness;

    await tester.tap(find.byKey(const Key('themeToggle')));
    await tester.pumpAndSettle();

    final Brightness updatedBrightness = Theme.of(
      tester.element(find.byType(Scaffold).first),
    ).brightness;
    expect(
      updatedBrightness,
      initialBrightness == Brightness.dark ? Brightness.light : Brightness.dark,
    );

    expect(find.byIcon(Icons.visibility), findsOneWidget);
    await tester.tap(find.byKey(const Key('togglePasswordVisibility')));
    await tester.pump();
    expect(find.byIcon(Icons.visibility_off), findsOneWidget);
  });
}
