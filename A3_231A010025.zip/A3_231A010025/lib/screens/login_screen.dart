import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/app_header.dart';
import '../widgets/profile_card.dart';
import 'layout_comparison_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onToggleTheme});

  final ValueChanged<Brightness> onToggleTheme;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<_LoginFormState> _formKey = GlobalKey<_LoginFormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            if (constraints.maxWidth >= 760) {
              return _buildLandscape(context, constraints.maxWidth);
            }
            return _buildPortrait(context, constraints.maxWidth);
          },
        ),
      ),
    );
  }

  Widget _buildPortrait(BuildContext context, double screenWidth) {
    return SingleChildScrollView(
      key: const Key('portraitLoginLayout'),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Column(
            children: <Widget>[
              AppHeader(
                height: 196,
                onToggleTheme: () =>
                    widget.onToggleTheme(Theme.of(context).brightness),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    _LoginForm(key: _formKey, fieldWidth: screenWidth - 48),
                    const SizedBox(height: 20),
                    const ProfileCard(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLandscape(BuildContext context, double screenWidth) {
    final double contentWidth = screenWidth.clamp(760, 1440);
    final double leftWidth = contentWidth * 0.38;
    final double rightWidth = contentWidth - leftWidth;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1440),
        child: Row(
          key: const Key('wideLoginLayout'),
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: leftWidth,
              child: Column(
                children: <Widget>[
                  AppHeader(
                    height: 190,
                    onToggleTheme: () =>
                        widget.onToggleTheme(Theme.of(context).brightness),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(20, 16, 12, 20),
                      child: const ProfileCard(),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              width: rightWidth,
              child: SingleChildScrollView(
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 620),
                    child: _LoginForm(
                      key: _formKey,
                      fieldWidth: rightWidth - 48,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LoginForm extends StatefulWidget {
  const _LoginForm({super.key, required this.fieldWidth});

  final double fieldWidth;

  @override
  State<_LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<_LoginForm> {
  final GlobalKey<FormState> _formStateKey = GlobalKey<FormState>();
  final TextEditingController _studentIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _rememberMe = false;
  bool _obscurePassword = true;

  @override
  void dispose() {
    _studentIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _submit() {
    FocusScope.of(context).unfocus();
    if (!_formStateKey.currentState!.validate()) {
      return;
    }
    _showMessage(
      _rememberMe
          ? 'Đăng nhập (mô phỏng) thành công · Đã ghi nhớ đăng nhập'
          : 'Đăng nhập (mô phỏng) thành công',
    );
  }

  void _openComparison() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const LayoutComparisonScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final double spacing = 14;

    return Form(
      key: _formStateKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'Đăng nhập hệ thống',
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineSmall,
          ),
          const SizedBox(height: 6),
          Text(
            'Nhập MSSV và mật khẩu để tiếp tục',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.extension<A3Colors>()!.muted,
            ),
          ),
          SizedBox(height: spacing + 6),
          _buildFields(),
          const SizedBox(height: 6),
          Row(
            children: <Widget>[
              Expanded(
                child: CheckboxListTile(
                  key: const Key('rememberCheckbox'),
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  title: const Text(
                    'Ghi nhớ đăng nhập',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  value: _rememberMe,
                  onChanged: (bool? value) {
                    setState(() => _rememberMe = value ?? false);
                  },
                ),
              ),
              TextButton(
                key: const Key('forgotPasswordButton'),
                onPressed: () => _showMessage(
                  'Vui lòng liên hệ giảng viên để đặt lại mật khẩu.',
                ),
                child: const Text('Quên mật khẩu?'),
              ),
            ],
          ),
          const SizedBox(height: 2),
          SizedBox(
            height: 52,
            child: FilledButton(
              key: const Key('loginButton'),
              onPressed: _submit,
              child: const Text(
                'ĐĂNG NHẬP',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Divider(
                    height: 1,
                    color: theme.extension<A3Colors>()!.divider,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    'hoặc',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.extension<A3Colors>()!.muted,
                    ),
                  ),
                ),
                Expanded(
                  child: Divider(
                    height: 1,
                    color: theme.extension<A3Colors>()!.divider,
                  ),
                ),
              ],
            ),
          ),
          OutlinedButton.icon(
            key: const Key('schoolLoginButton'),
            onPressed: () =>
                _showMessage('Đăng nhập trường hiện là chức năng minh họa.'),
            icon: const Icon(Icons.account_balance_outlined),
            label: const Text('Đăng nhập bằng tài khoản trường'),
          ),
          const SizedBox(height: 8),
          Wrap(
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: <Widget>[
              const Text('Chưa có tài khoản?'),
              TextButton(
                key: const Key('registerButton'),
                onPressed: () =>
                    _showMessage('Chức năng đăng ký hiện là phần minh họa.'),
                child: const Text('Đăng ký'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            key: const Key('comparisonButton'),
            onPressed: _openComparison,
            icon: const Icon(Icons.view_quilt_outlined),
            label: const Text('Xem bản bố cục linh hoạt'),
          ),
        ],
      ),
    );
  }

  Widget _buildFields() {
    final List<Widget> fields = <Widget>[
      TextFormField(
        key: const Key('studentIdField'),
        controller: _studentIdController,
        keyboardType: TextInputType.text,
        textCapitalization: TextCapitalization.characters,
        textInputAction: TextInputAction.next,
        autofillHints: const <String>[AutofillHints.username],
        decoration: const InputDecoration(
          labelText: 'Mã số sinh viên',
          prefixIcon: Icon(Icons.badge_outlined),
        ),
        validator: (String? value) {
          if (value == null || value.trim().isEmpty) {
            return 'Vui lòng nhập mã số sinh viên';
          }
          if (!RegExp(r'^[A-Za-z0-9]+$').hasMatch(value.trim())) {
            return 'Mã số sinh viên chỉ gồm chữ và số';
          }
          return null;
        },
      ),
      TextFormField(
        key: const Key('passwordField'),
        controller: _passwordController,
        obscureText: _obscurePassword,
        textInputAction: TextInputAction.done,
        autofillHints: const <String>[AutofillHints.password],
        onFieldSubmitted: (_) => _submit(),
        decoration: InputDecoration(
          labelText: 'Mật khẩu',
          prefixIcon: const Icon(Icons.lock_outline),
          suffixIcon: IconButton(
            key: const Key('togglePasswordVisibility'),
            tooltip: _obscurePassword ? 'Hiện mật khẩu' : 'Ẩn mật khẩu',
            onPressed: () {
              setState(() => _obscurePassword = !_obscurePassword);
            },
            icon: Icon(
              _obscurePassword ? Icons.visibility : Icons.visibility_off,
            ),
          ),
        ),
        validator: (String? value) {
          if (value == null || value.isEmpty) {
            return 'Vui lòng nhập mật khẩu';
          }
          return null;
        },
      ),
    ];

    if (widget.fieldWidth >= 620) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(child: fields[0]),
          const SizedBox(width: 12),
          Expanded(child: fields[1]),
        ],
      );
    }

    return Column(
      children: <Widget>[fields[0], const SizedBox(height: 14), fields[1]],
    );
  }
}
