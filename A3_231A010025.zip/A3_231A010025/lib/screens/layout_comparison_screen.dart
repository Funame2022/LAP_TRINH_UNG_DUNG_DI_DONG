import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class LayoutComparisonScreen extends StatelessWidget {
  const LayoutComparisonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Bản bố cục linh hoạt · Flutter')),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          final bool wide = constraints.maxWidth >= 620;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 840),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      'Ví dụ bố cục thích ứng',
                      style: theme.textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Flutter không có widget ConstraintLayout tích hợp sẵn. '
                      'Màn hình này dùng LayoutBuilder để chọn cách sắp xếp '
                      'phù hợp với bề rộng khả dụng.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.extension<A3Colors>()!.muted,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Flex(
                      direction: wide ? Axis.horizontal : Axis.vertical,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: _buildDemoPanels(wide),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  List<Widget> _buildDemoPanels(bool wide) {
    const Widget narrowPanel = _DemoPanel(
      icon: Icons.view_agenda_outlined,
      title: 'Bố cục hẹp',
      description:
          'Các trường nhập liệu xếp theo một cột, phù hợp với điện thoại.',
    );
    const Widget widePanel = _DemoPanel(
      icon: Icons.view_column_outlined,
      title: 'Bố cục rộng',
      description:
          'Các nội dung liên quan được đặt cạnh nhau khi có đủ không gian.',
    );

    if (wide) {
      return <Widget>[
        const Expanded(flex: 5, child: narrowPanel),
        const SizedBox(width: 16),
        const Expanded(flex: 5, child: widePanel),
      ];
    }

    return <Widget>[
      const SizedBox(width: double.infinity, child: narrowPanel),
      const SizedBox(height: 16),
      const SizedBox(width: double.infinity, child: widePanel),
    ];
  }
}

class _DemoPanel extends StatelessWidget {
  const _DemoPanel({
    required this.icon,
    required this.title,
    required this.description,
  });

  final IconData icon;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon, color: theme.colorScheme.primary, size: 28),
            const SizedBox(height: 12),
            Text(title, style: theme.textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(
              description,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.extension<A3Colors>()!.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
