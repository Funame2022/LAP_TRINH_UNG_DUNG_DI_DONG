import 'package:flutter/material.dart';

class ProfileCard extends StatelessWidget {
  const ProfileCard({super.key});

  static const String studentId = '231A010025';
  static const String studentName = 'Họ và tên: Nguyễn Thịnh Phú';

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final A3ProfileColors colors = A3ProfileColors.from(theme);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(studentName, style: theme.textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              'MSSV: $studentId',
              style: theme.textTheme.bodyMedium?.copyWith(color: colors.muted),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Divider(height: 1, color: colors.divider),
            ),
            const _ProfileDetail(
              icon: Icons.class_outlined,
              label: 'Lớp: 231A29032',
            ),
            const SizedBox(height: 10),
            const _ProfileDetail(
              icon: Icons.mail_outline,
              label: 'phu231a010025@vhu.edu.vn',
            ),
            const SizedBox(height: 16),
            const Row(
              children: <Widget>[
                Expanded(
                  child: _ProfileStat(value: '3', label: 'Lab đã nộp'),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: _ProfileStat(value: '8.5', label: 'Điểm TB'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileDetail extends StatelessWidget {
  const _ProfileDetail({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Row(
      children: <Widget>[
        Icon(icon, size: 18, color: theme.colorScheme.primary),
        const SizedBox(width: 10),
        Expanded(child: Text(label, style: theme.textTheme.bodyMedium)),
      ],
    );
  }
}

class _ProfileStat extends StatelessWidget {
  const _ProfileStat({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final Color muted = theme.textTheme.bodySmall?.color ?? theme.hintColor;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Column(
          children: <Widget>[
            Text(
              value,
              style: theme.textTheme.titleLarge?.copyWith(
                color: theme.colorScheme.primary,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall?.copyWith(
                color: muted,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class A3ProfileColors {
  const A3ProfileColors({required this.muted, required this.divider});

  final Color muted;
  final Color divider;

  factory A3ProfileColors.from(ThemeData theme) {
    return A3ProfileColors(
      muted: theme.textTheme.bodyMedium?.color ?? theme.hintColor,
      divider: theme.dividerColor,
    );
  }
}
