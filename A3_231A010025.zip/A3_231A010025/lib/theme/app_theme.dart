import 'package:flutter/material.dart';

abstract final class AppTheme {
  static const Color primary = Color(0xFF0468D7);
  static const Color tertiary = Color(0xFF00A6A6);

  static ThemeData get light => _build(
    brightness: Brightness.light,
    colorScheme: const ColorScheme(
      brightness: Brightness.light,
      primary: primary,
      onPrimary: Colors.white,
      secondary: tertiary,
      onSecondary: Colors.white,
      error: Color(0xFFBA1A1A),
      onError: Colors.white,
      surface: Color(0xFFFFFFFF),
      onSurface: Color(0xFF171A1D),
      outline: Color(0xFF87939D),
      outlineVariant: Color(0xFFD5DDE3),
      surfaceContainerHighest: Color(0xFFEEF2F6),
    ),
    background: const Color(0xFFF7F9FC),
    muted: const Color(0xFF5B6770),
    primaryContainer: const Color(0xFFD6E6FB),
  );

  static ThemeData get dark => _build(
    brightness: Brightness.dark,
    colorScheme: const ColorScheme(
      brightness: Brightness.dark,
      primary: Color(0xFFA7C8FF),
      onPrimary: Color(0xFF082F57),
      secondary: Color(0xFF75D5CE),
      onSecondary: Color(0xFF063733),
      error: Color(0xFFFFB4AB),
      onError: Color(0xFF690005),
      surface: Color(0xFF171A1D),
      onSurface: Color(0xFFE3E2E6),
      outline: Color(0xFF89939D),
      outlineVariant: Color(0xFF41474E),
      surfaceContainerHighest: Color(0xFF252A30),
    ),
    background: const Color(0xFF111417),
    muted: const Color(0xFFBAC4CE),
    primaryContainer: const Color(0xFF24466C),
  );

  static ThemeData _build({
    required Brightness brightness,
    required ColorScheme colorScheme,
    required Color background,
    required Color muted,
    required Color primaryContainer,
  }) {
    final TextTheme textTheme = ThemeData(
      brightness: brightness,
      useMaterial3: true,
    ).textTheme;

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: background,
      textTheme: textTheme.copyWith(
        headlineSmall: textTheme.headlineSmall?.copyWith(
          fontSize: 24,
          fontWeight: FontWeight.w700,
        ),
        bodyMedium: textTheme.bodyMedium?.copyWith(fontSize: 14),
        labelLarge: textTheme.labelLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      extensions: <ThemeExtension<dynamic>>[
        A3Colors(
          background: background,
          muted: muted,
          primaryContainer: primaryContainer,
          divider: colorScheme.outlineVariant,
        ),
      ],
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: colorScheme.primary, width: 2),
        ),
        filled: true,
        fillColor: colorScheme.surface,
      ),
      cardTheme: CardThemeData(
        color: colorScheme.surface,
        elevation: 2,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          minimumSize: const Size(48, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(48, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      checkboxTheme: CheckboxThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
    );
  }
}

@immutable
class A3Colors extends ThemeExtension<A3Colors> {
  const A3Colors({
    required this.background,
    required this.muted,
    required this.primaryContainer,
    required this.divider,
  });

  final Color background;
  final Color muted;
  final Color primaryContainer;
  final Color divider;

  @override
  A3Colors copyWith({
    Color? background,
    Color? muted,
    Color? primaryContainer,
    Color? divider,
  }) {
    return A3Colors(
      background: background ?? this.background,
      muted: muted ?? this.muted,
      primaryContainer: primaryContainer ?? this.primaryContainer,
      divider: divider ?? this.divider,
    );
  }

  @override
  A3Colors lerp(ThemeExtension<A3Colors>? other, double t) {
    if (other is! A3Colors) {
      return this;
    }
    return A3Colors(
      background: Color.lerp(background, other.background, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      primaryContainer: Color.lerp(primaryContainer, other.primaryContainer, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
    );
  }
}
