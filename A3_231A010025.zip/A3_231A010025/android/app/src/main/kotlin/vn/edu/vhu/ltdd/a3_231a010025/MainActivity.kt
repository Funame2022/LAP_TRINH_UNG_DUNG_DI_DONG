package vn.edu.vhu.ltdd.a3_231a010025

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
